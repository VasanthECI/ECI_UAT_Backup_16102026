/*({
    invoke : function(component, event, helper) {
        // Get the record ID attribute
        var record = component.get("v.recordId");
        
        // Get the current URL
        var currentUrl = window.location.href;
        
        // Option 1: Refresh the current page
        $A.get('e.force:refreshView').fire();
        
        // Option 2: Navigate to the same record page (forces a complete reload)
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": record,
            "isRedirect": true  // This forces a hard redirect
        });
        navEvt.fire();
        
        // Option 3: If you're in a flow, you can also use the flow finish event
        var navigateEvent = $A.get("e.force:navigateToComponent");
        navigateEvent.setParams({
            componentDef: "c:yourComponentName",
            componentAttributes: {
                recordId: record
            }
        });
        navigateEvent.fire();
    }
})*/

/*({    invoke : function(component, event, helper) {
   // Get the record ID attribute
   var record = component.get("v.recordId");
   
   // Get the Lightning event that opens a record in a new tab
   var redirect = $A.get("e.force:navigateToSObject");
   
   // Pass the record ID to the event
   redirect.setParams({
      "recordId": record
   });
        
   // Open the record
   redirect.fire();
}})*/

/*({
    invoke : function(component, event, helper) {
        // Get the record ID attribute
        var record = component.get("v.recordId");
        
        // For flows, you can close the flow and refresh the page
        // This assumes you're using this in a flow finish action
        var dismissActionPanel = $A.get("e.force:closeQuickAction");
        dismissActionPanel.fire();
        
        // Then refresh the view
        window.setTimeout(
            $A.getCallback(function() {
                $A.get('e.force:refreshView').fire();
            }), 1000
        );
    }
})*/

({
    invoke : function(component, event, helper) {
        // Get the record ID attribute
        var record = component.get("v.recordId");
        
        // Refresh the view in the same tab
        $A.get('e.force:refreshView').fire();
        
        // If you need a complete page reload, use a navigation event with redirect
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": record,
            "isRedirect": true  // Forces a complete reload in the same tab
        });
        navEvt.fire();
    }
})