/**
 * @description       : Invisible utility bar item that facilitates communication between omni channel work load and VCC agent presence.
 * @author            : kendra@snowytree.com
 * @last modified on  : 4-29-2024
 * @last modified by  : Kendra Broom
 * Modifications Log 
 * Ver   Date         Author                  Modification
 * 1.0   4-29-2024   kendra@snowytree.com   Initial Version
**/

({
    onWorkAccepted: function(component, event, helper) {
        try {
            var readyState = false;
            var workItemId = event.getParam('workItemId');
            var workObject = workItemId.substring(0, 3);

            console.log('Work Item Object: ' + workObject);

            // Checking if workObject is not VoiceCall
            if (workObject !== '0LQ') {
                console.log('Accepted Ready state: ' + readyState);
                var action = helper.makeServerCallout(component, readyState);

                action.setCallback(this, function(response) { 
                    var state = response.getState();
                    var notifLib = component.find('notifLib');
                    if (state === "SUCCESS" && notifLib) {
                        notifLib.showToast({
                            "title": "Success",
                            "message": "Accepted work item. Setting VCC Agent State to Away. Omni status will not change.",
                            "variant": "success"
                        });
                    } else if (state === "ERROR" && notifLib) {
                        console.error("Server callout failed or Notification library component not found");
                        notifLib.showToast({
                            "title": "Error",
                            "message": "Failed to update VCC Agent State.",
                            "variant": "error"
                        });
                    }
                });
                $A.enqueueAction(action);
            }
        } catch (e) {
            console.error("Error processing work accepted event - " + e.message);
        }
    },

    onWorkClosed: function(component, event, helper) {        
        try {
            var workItemId = event.getParam('workItemId');
            var workObject = workItemId.substring(0, 3);

            if (workObject !== '0LQ') {
            var omniAPI = component.find("omniToolkit");
            omniAPI.getAgentWorks().then(function(result) {
                var works = JSON.parse(result.works);
                if (works.length === 0) {
                    var readyState = true;
                    console.log('No work items left');
                    var action = helper.makeServerCallout(component, readyState);

                    action.setCallback(this, function(response) { 
                        var state = response.getState();
                        var notifLib = component.find('notifLib');
                        if (state === "SUCCESS" && notifLib) {
                            notifLib.showToast({
                                "title": "Success",
                                "message": "Work item closed. Setting VCC Agent State to Ready. Omni status will not change.",
                                "variant": "success"
                            });
                        } else {
                            console.error("Server callout failed or Notification library component not found");
                            if (notifLib) {
                                notifLib.showToast({
                                    "title": "Error",
                                    "message": "Failed to update VCC Agent State.",
                                    "variant": "error"
                                });
                            }
                        }
                    });
                    $A.enqueueAction(action);
                }
            });
        }
        } catch (e) {
            console.error("Error processing work accepted event - " + e.message);
        }
    }
})