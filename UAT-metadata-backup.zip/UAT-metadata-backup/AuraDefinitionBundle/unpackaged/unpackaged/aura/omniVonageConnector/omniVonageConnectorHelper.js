({
    makeServerCallout : function(component, readyState) {
        var action = component.get("c.makeCallout"); // Fetches the apex method
        action.setParams({ "readyState" : readyState });

        return action;
    }
})