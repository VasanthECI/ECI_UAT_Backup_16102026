({
    navigate  : function(component, event, helper) {
        $A.get("e.force:closeQuickAction").fire();
        var action = component.get("c.getOppDetails");
        action.setParams({ oppid : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            var wrap=response.getReturnValue();
            
            if (state === "SUCCESS") {
                if(wrap.opp.CurrencyIsoCode!='USD'){
                    window.open($A.get("$Label.c.NavCreditCardAuthorizationURL")+"OPID="+wrap.opp.Id.substring(0,15)+"&SLSPEmail="+wrap.opp.Owner.Email.replaceAll('@','%40')+"&Amount="+(wrap.opp.Amount!=undefined?wrap.opp.Amount:'')+"&CustomerID="+(wrap.opp.Great_Plains_Number__c!=undefined?wrap.opp.Great_Plains_Number__c:'')+"&CustomerEmail="+(wrap.conRole!=null?(wrap.conRole.Contact.Email!=undefined?wrap.conRole.Contact.Email.replaceAll('@','%40'):''):'')+"&CurrencyIsoCode="+wrap.opp.CurrencyIsoCode+"&Name="+wrap.opp.Account.Name.replaceAll(' ','+')+"&SLSP="+wrap.opp.Owner.Name.replaceAll(' ','+'));
                }
                else{
                    window.open($A.get("$Label.c.CreditCardAuthorization")+"/Authorize.php?OPID="+wrap.opp.Id.substring(0,15)+"&Name="+wrap.opp.Account.Name.replaceAll(' ','+')+"&SLSPEmail="+wrap.opp.Owner.Email.replaceAll('@','%40')+"&SLSP="+wrap.opp.Owner.Name.replaceAll(' ','+')+"&City="+wrap.opp.Account.BillingCity+"&State="+wrap.opp.Account.BillingState.replaceAll(' ','+')+"&Zip="+wrap.opp.Account.BillingPostalCode+"&CustomerID="+(wrap.opp.Account.Great_Plains_ID__c!=undefined?wrap.opp.Account.Great_Plains_ID__c:'')+"&CustomerEmail="+(wrap.conRole!=null?(wrap.conRole.Contact.Email!=undefined?wrap.conRole.Contact.Email.replaceAll('@','%40'):''):'')+"&BU="+(wrap.opp.Product_Line__c!=undefined? wrap.opp.Product_Line__c:''));
                }
            }
            else {
                console.log("Failed with state: " + state);
            }
        });
        $A.enqueueAction(action);
    }
})