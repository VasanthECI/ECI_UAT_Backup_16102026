<aura:application extends="ltng:outApp" access="global">
    <aura:dependency resource="c:QuotaAdjustmentLineButton"/>
</aura:application>