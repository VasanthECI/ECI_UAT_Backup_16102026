/**
 * Class Name: LWCProductCreationToolController
 * Description:
 *  Aura Controller to handle event-based redirection logic.
 *  Specifically used to navigate to a newly created record's detail page
 *  when an LWC (Lightning Web Component) sends a message event containing
 *  the recordId via messageTemplateData. 
 *  It excludes redirection for certain record types like Task and Event.
 * 
 * Author: 
 * Date Created: 
 * Last Modified: 17/07/2025
 * 
 * Version History:
 * Version : 1.1
 * Author  : Surya
 * Changes : modified the logic to fetch executionComponent dynamically.
 * Date    : 17/07/2025
 */
({
    redirectToNewRecord: function(component, event, helper) {
        var messageData = event.getParam('messageTemplateData');
        console.log('messageTemplateData:', messageData);
        if (!$A.util.isEmpty(messageData)) {
            var excludeRedirectList = ['Task','Event'];
            
            var executionComponent = messageData.find(d => typeof d === 'object' && d.executionComponent);

            if (!$A.util.isEmpty(executionComponent) && !(excludeRedirectList.includes(messageData[0]))) {
                var recordId = executionComponent.executionComponent.attributes.recordId;
                var navEvt = $A.get("e.force:navigateToSObject");
                navEvt.setParams({
                    "recordId": recordId,
                    "slideDevName": "related"
                });
                navEvt.fire();
            }
        }
    }
})