({
    doInit : function(component, event, helper) {
        var channel = '/event/QuoteRefreshEvent__e';
        const replayId = -1;
        
        const empApi = component.find("empApi");
        
        //A callback function that's invoked for every event received
        const callback = function (message) 
        {
            var url = window.location.href;
            if (url.includes("lightning/r/SBQQ__Quote__c")) 
            {
                console.log(" ==== > Refreshed Sucessfully < === ");
                $A.get("e.force:refreshView").fire();
            } 
            var obj = message.data.payload;
        };
        
        // Subscribe to the channel and save the returned subscription object.
        empApi.subscribe(channel, replayId, callback).then(function(newSubscription) {
            //console.log("Subscribed to channel 1" + channel);
        });
        
        const errorHandler = function (message) {
            console.error("Received error ", JSON.stringify(message));
        };
        
        //A callback function that's called when an error response is received from the server for the handshake, connect, subscribe, and unsubscribe meta channels.
        empApi.onError(errorHandler);
    }
})