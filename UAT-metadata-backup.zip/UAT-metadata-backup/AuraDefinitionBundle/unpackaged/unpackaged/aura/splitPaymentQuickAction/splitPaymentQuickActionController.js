({
    handleClose: function (component, event) {
        if (event.getParam('refresh') === true) {
            $A.get('e.force:refreshView').fire();
        }
        $A.get('e.force:closeQuickAction').fire();
    }
})