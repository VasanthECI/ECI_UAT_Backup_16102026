({
    handleClick: function(component, event, helper) {
        var action = component.get("c.getCustomURL");// Fetch the confirmation token using the method from the controller class.
        
        // Set up the callback function
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                var url = component.get("v.url"); // URL obtained from the flow
                if (url) {
                    window.location.href = url + '&_CONFIRMATIONTOKEN=' + result;
                }
            } else {
                console.error("Error: " + JSON.stringify(response.getError()));
            }
        });
        
        // Enqueue the action to be sent to the server
        $A.enqueueAction(action);
    }
})