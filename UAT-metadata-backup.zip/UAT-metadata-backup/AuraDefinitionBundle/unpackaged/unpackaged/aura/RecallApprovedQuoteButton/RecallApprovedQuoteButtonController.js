({
    doInit : function(component, event, helper) {
        
        var action = component.get("c.getQuoteDetails");
        action.setParams({ quoteId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            var quote=response.getReturnValue();
            if (state === "SUCCESS") {
                if(quote.SBQQ__Status__c=='Approved'){
                    var action2 = component.get("c.updateQuote");
                    action2.setParams({ quoteId : component.get("v.recordId") });
                    action2.setCallback(this, function(response2) {
                        var state2 = response2.getState();
                        var quote2=response.getReturnValue();
                        if (state2 === "SUCCESS") {
                            
                             $A.get('e.force:refreshView').fire();
                             $A.get("e.force:closeQuickAction").fire();
                            var loading=component.get('v.loading');
                            component.set('v.loading',false);
                            //window.location.reload();
                        }else{
                            var errors = response2.getError();
                            if (errors) {
                                if (errors[0] && errors[0].message) {
                                    var toastEvent = $A.get("e.force:showToast");
                                    toastEvent.setParams({
                                        "title": "Error!",
                                        "type" : 'error',
                                        "mode" : 'sticky',
                                        "message": errors[0].message
                                    });
                                    toastEvent.fire();
                                }
                            } else {
                                console.log("Unknown error");
                            }
                             $A.get("e.force:closeQuickAction").fire();
                            var loading=component.get('v.loading');
                            component.set('v.loading',false);
                        }
                    });
                    $A.enqueueAction(action2);
                }else{
                    $A.get("e.force:closeQuickAction").fire();
                            var loading=component.get('v.loading');
                            component.set('v.loading',false);
                }
            }
            else {
                console.log("Failed with state: " + JSON.stringify(response.getError()));
            }
        });
        $A.enqueueAction(action);
    }
    
})