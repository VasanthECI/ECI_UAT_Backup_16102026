({
    doInit : function(component, event, helper) {
        let action = component.get('c.OriginalOppToNegOpp');
        action.setParams({"newid":component.get("v.recordId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(component.isValid() && state == "SUCCESS"){
                console.log('Created Successfully');
                let result=response.getReturnValue();
                console.log('Created result',result);
                $A.get("e.force:closeQuickAction").fire();
                var loading=component.get('v.loading');
                component.set('v.loading',false);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    message: result,
                    duration:' 5000',
                    key: 'info_alt',
                    type: 'info',
                    mode: 'dismissible'
                });
                toastEvent.fire();
            } else {
                console.log('There was a problem : '+response.getError());
                $A.get("e.force:closeQuickAction").fire();
                var loading=component.get('v.loading');
                component.set('v.loading',false);
                $A.get("e.force:closeQuickAction").fire();
                var loading=component.get('v.loading');
                component.set('v.loading',false);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    message: $A.get("$Label.c.ReversalOppErrorNotification"),
                    duration:' 5000',
                    key: 'info_alt',
                    type: 'info',
                    mode: 'dismissible'
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    }
})