({
    doInit : function(component, event, helper) {
        console.log(component.get('v.oppId'));
        let hostname = window.location.hostname;
        let action = component.get('c.createQuotaAdjustment');
        action.setParams({"opplineId":component.get("v.oppId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(component.isValid() && state == "SUCCESS"){
                console.log('Created Successfully',hostname);
                let result=response.getReturnValue();
                console.log('Created result',result);
                let url = result;
                window.open(url,'_top')
            } else {
                console.log('There was a problem : '+response.getError());
                $A.get("e.force:closeQuickAction").fire();
                var loading=component.get('v.loading');
                component.set('v.loading',false);
                $A.get("e.force:closeQuickAction").fire();
                var loading=component.get('v.loading');
                component.set('v.loading',false);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    message: 'Error while creating ',
                    duration:' 5000',
                    key: 'info_alt',
                    type: 'info',
                    mode: 'dismissible'
                });
                toastEvent.fire();
            }
        });
        
        $A.enqueueAction(action);
    }
})