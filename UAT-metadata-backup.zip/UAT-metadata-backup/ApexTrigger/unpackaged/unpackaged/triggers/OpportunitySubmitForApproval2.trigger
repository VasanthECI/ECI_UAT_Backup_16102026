Trigger OpportunitySubmitForApproval2 on Opportunity (after update) {
    
    Map<Id, Callout_Log__c> opportunityCallOuts = new Map<Id, Callout_Log__c>();
    if(trigger.isAfter){
        if(trigger.isUpdate){
            if(!UtilClass.isSubmitted)
            { 
                List<Opportunity> opportunities = new List<Opportunity>();
                for(opportunity opp : trigger.new){
                    if(opp.stageName != trigger.oldMap.get(opp.Id).stageName && opp.StageName=='Sent To Accounting'){
                        opportunities.add(opp);    
                    }    
                }
                if(opportunities.size() > 0){
                    UtilClass UC = new UtilClass();
                    UC.approveOpp(opportunities);    
                }
                
            }
            
            //Lasso API Response
            if(!system.isFuture() ){ 
                List<Opportunity> closedWonOppts = new List<Opportunity>();
                for(opportunity opp:trigger.new){
                    if(opp.isWon && opp.isClosed){
                        closedWonOppts.add(opp);    
                    }    
                }
                if(closedWonOppts.size() > 0 && ! RHCOpportunityClosedWonNotifierHelper.calloutExecuted){
                    opportunityCallOuts = RHCOpportunityClosedWonNotifierHelper.opportunityLogs(closedWonOppts);   
                }
                
                if(!RHCOpportunityClosedWonNotifierHelper.executed && closedWonOppts.size() > 0 )
                {
                    RHCOpportunityClosedWonNotifierHelper.opportunityWonNotifier(closedWonOppts, opportunityCallOuts); 
                }else{
                    System.debug('opportunityWonNotifier not executed');
                }
            }
        }
    } 
}