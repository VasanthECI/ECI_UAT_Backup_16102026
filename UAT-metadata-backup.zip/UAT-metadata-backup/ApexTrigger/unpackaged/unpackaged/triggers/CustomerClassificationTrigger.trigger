trigger CustomerClassificationTrigger on Customer_Classification__c (before insert,before Update, after insert,after update, after delete) {
    if(Trigger.isbefore){
        if(trigger.isInsert){
            CustomerClassificationHelper.duplicateClassifications(trigger.new,trigger.oldMap,false);
        }
        if(trigger.isUpdate){
            CustomerClassificationHelper.duplicateClassifications(trigger.new,trigger.oldMap,true);
        }
    }
    if(Trigger.isAfter){
        if(trigger.isInsert){
            CustomerClassificationHelper.insertClassifications(trigger.new);
        }
       if(trigger.isUpdate){
            CustomerClassificationHelper.updateClassifications(trigger.new,trigger.oldMap);
        }
        if(trigger.isDelete){
           CustomerClassificationHelper.insertClassifications(trigger.old); 
        }
    }

}