trigger ProductCreationRequestTrigger on SKU_Product_Creation_Request__c (before update,before delete) {
    if (Trigger.isBefore && Trigger.isUpdate) {
        
       ProductCreationRequestHandler.lockFields(Trigger.new, Trigger.oldMap);
    }
    
}