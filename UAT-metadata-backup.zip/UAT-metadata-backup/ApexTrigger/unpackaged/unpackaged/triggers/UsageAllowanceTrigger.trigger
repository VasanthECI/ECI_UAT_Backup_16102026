/**
 * @description Apex trigger on `Usage_Allowance__c`. Fires after every
 *              persistent change to an allowance (insert, update,
 *              delete, undelete) and routes context to
 *              `UsageAllowanceTriggerHandler` so the parent
 *              `Contract.UsageEnabled__c` flag stays in sync with the
 *              presence of any active allowances.
 *
 *              Per the project standard the trigger is logic-free; it
 *              only routes Trigger context into the handler class.
 *
 *              Why all four DML contexts:
 *                - after insert  — a new active allowance can flip the
 *                  contract from disabled → enabled.
 *                - after update  — `Is_Active__c` may have flipped on
 *                  an existing allowance.
 *                - after delete  — the last active allowance on a
 *                  contract being removed must flip the contract back
 *                  to disabled.
 *                - after undelete — a recovered active allowance can
 *                  flip the contract back on.
 *
 *              `Contract__c` on `Usage_Allowance__c` is a non-
 *              reparentable Master-Detail relationship, so the parent
 *              cannot change on update — the handler does not need to
 *              consider the prior parent on update.
 *
 * @author Michael Morrell
 * @version 2.0
 * @since 2026-05-07
 *
 * Versioning:
 * - 2.0 (2026-05-10) — Stable Release for UAT (first promotion out of
 *   sandbox). Routes all four DML phases to
 *   `UsageAllowanceTriggerHandler` so the parent
 *   `Contract.UsageEnabled__c` stays in sync. Consolidates the v1.x
 *   pre-stable increments; see
 *   `POC/ECI_Usage_Ingestion/RELEASE_NOTES_2.0.md` for the full
 *   pre-stable changelog.
 */
trigger UsageAllowanceTrigger on Usage_Allowance__c (
    after insert, after update, after delete, after undelete
) {
    if (Trigger.isAfter && Trigger.isInsert) {
        UsageAllowanceTriggerHandler.onAfterInsert(Trigger.new);
    } else if (Trigger.isAfter && Trigger.isUpdate) {
        UsageAllowanceTriggerHandler.onAfterUpdate(Trigger.new, Trigger.oldMap);
    } else if (Trigger.isAfter && Trigger.isDelete) {
        UsageAllowanceTriggerHandler.onAfterDelete(Trigger.old);
    } else if (Trigger.isAfter && Trigger.isUndelete) {
        UsageAllowanceTriggerHandler.onAfterUndelete(Trigger.new);
    }
}