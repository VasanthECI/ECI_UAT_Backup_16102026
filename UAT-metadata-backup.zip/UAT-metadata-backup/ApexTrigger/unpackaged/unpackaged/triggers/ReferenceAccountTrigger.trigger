/**
* @description
* Trigger on Reference_Account__c to process Account sharing asynchronously.
*
* This trigger collects related Account Ids from Reference_Account__c records
* and invokes the AccountSharingQueueable class for further processing.
*
* ------------------------------------------------------------
* 🔹 Trigger Events
* ------------------------------------------------------------
* - after insert
* - after update
*
* ------------------------------------------------------------
* 🔹 Logic Overview
* ------------------------------------------------------------
*
* 1. AFTER INSERT:
*    - Collects Account Ids from:
*         • Reseller_Distributor__c
*         • EndUser_Account__c
*
* 2. AFTER UPDATE:
*    - Executes only when:
*         Parent_Support_View__c field value is changed
*    - Collects related Account Ids
*
* 3. ASYNC EXECUTION:
*    - Enqueues AccountSharingQueueable if Account Ids exist
*
* ------------------------------------------------------------
* 🔹 Features
* ------------------------------------------------------------
* - Bulkified using Set<Id>
* - Prevents duplicate processing
* - Uses Queueable Apex for async processing
*
* ------------------------------------------------------------
* 🔹 Fields Used
* ------------------------------------------------------------
* - Reseller_Distributor__c
* - EndUser_Account__c
* - Parent_Support_View__c
*
* ------------------------------------------------------------
* 🔹 Dependencies
* ------------------------------------------------------------
* - AccountSharingQueueable (Queueable Apex Class)
*
* ------------------------------------------------------------
* @author          Naveen S
* @createdDate     2026-04-10
* @lastModifiedBy  Naveen S
* @lastModifiedDate 2026-04-30
* @version         1.0
*/
trigger ReferenceAccountTrigger on Reference_Account__c (after insert, after update) {
    
    if (Trigger.isAfter) {
        
        Set<Id> accIds = new Set<Id>();
        
        // 🔹 AFTER INSERT
        if (Trigger.isInsert) {
            for (Reference_Account__c ref : Trigger.new) {
                if (ref.Id != null) {
                    accIds.add(ref.Reseller_Distributor__c);
                    accIds.add(ref.EndUser_Account__c);
                }
            }
        }
        
        // 🔹 AFTER UPDATE
        if (Trigger.isUpdate) {
            for (Reference_Account__c ref : Trigger.new) {
                
                Reference_Account__c oldRef = Trigger.oldMap.get(ref.Id);
                
                // Only when field value changes
                if (oldRef != null && 
                    ref.Parent_Support_View__c != oldRef.Parent_Support_View__c) {
                        
                        accIds.add(ref.Reseller_Distributor__c);
                        accIds.add(ref.EndUser_Account__c);
                    }
            }
        }
        
        // 🔹 CALL QUEUEABLE
        if (!accIds.isEmpty()) {
            System.debug('🚀 Enqueue Queueable for Records: ' + accIds);
            System.enqueueJob(new AccountSharingQueueable(accIds));
        }
    }
}