/**
* Apex Trigger : SubscriptionTrigger
* Description  :
* 
* Author: 
* Date Created: 
* Last Modified: 
* 
* Version History:
* Version : 1.3
* Author  : Vidhya
* Changes : Modified updatePrimaryProduct() - SFDEV-967 New Logic for updating Primary Product
            Refactored and moved to ContractPrimaryProductHandler class
* Date    : 20/May/2025

* Version : 1.4
* Author  : Aruljothi
* Changes : Handles renewal uplift logic for SBQQ__Subscription__c when the trigger switch is active.
			handleBeforeUpdate(),handleBeforeInsert() - Executes before insert/update to initialize fields and track uplift rate changes.
			updateContractEffectiveUpliftRates() - After insert, updates effective uplift rates on related Contracts.
* Date    : 06/12/2025

* Version : 1.5
* Author  : Vidhya
* Changes : SFDEV - 1155 Moving updatePrimaryProductOnContract after Account PrimaryProductTopARR__c is updated       
* Date    : 1/Sep/2025
*
* Version : 1.6
* Author  : Aruljothi
* Changes : SFDEV-1724 Call LicenseModuleManager only for subscriptions whose Product2.Nexus_Application__c is set
*           (filtering implemented in this trigger, not in LicenseModuleManager).
* Date    : 06/04/2026
*
* Version : 1.7
* Author  : Aruljothi
* Changes : Use TriggerSwitchCache.isTriggerActive for Trigger_Switch__mdt (one SOQL per transaction).
* Date    : 22/Apr/2026
*/

trigger SubscriptionTrigger on SBQQ__Subscription__c (after insert, after update,before insert, before update) {
    if(trigger.isAfter && trigger.isInsert){
        set<Id> contractIds = new set<Id>();
        
        // SFDEV-967 For Contract Primary Product update logic
        Map<Id, String> contractIdsWithPrimProductMap = new Map<Id, String>();
        
        List<SBQQ__Subscription__c> SubscriptionList = new List<SBQQ__Subscription__c>();
        for(SBQQ__Subscription__c sub : trigger.new){
            contractIds.add(sub.SBQQ__Contract__c);
            
            // Store existing PrimaryProduct__c in the map to compare during update
            contractIdsWithPrimProductMap.put(sub.SBQQ__Contract__c,sub.SBQQ__Contract__r.PrimaryProduct__c);
            
            if(sub.Nexus_Product__c != null){
                SubscriptionList.add(sub);
            }
        }
        if(!contractIds.isEmpty() && contractIds.size()>0){
            SubscriptionTriggerHandler.contractACVUpdate(contractIds); 
            SubscriptionTriggerHandler.createLicensesForContract(Trigger.new);
            //LicenseModulesTriggerHandler.createLicenseModules(Trigger.new);
        }
        
        if(!SubscriptionList.isEmpty()){
            SubscriptionTriggerHandler.UpdatePrimaryProductTopARR(SubscriptionList);
        }

         // SFDEV - 1155 Moving code here after Account PrimaryProductTopARR__c is updated from above function
         // SFDEV - 967 - Handle Contract Primary Product update logic
         if(!contractIdsWithPrimProductMap.isEmpty() && contractIdsWithPrimProductMap.size()>0){          
            ContractPrimaryProductHandler.updatePrimaryProductOnContract(contractIdsWithPrimProductMap);
        }        
       
    }
    
   if (TriggerSwitchCache.isTriggerActive('License_Module__c')) {
    System.debug('LicenseModule Trigger Activated');

    if (Trigger.isAfter && (Trigger.isInsert || Trigger.isUpdate)
            && !LicenseModuleManager.isAutomatedUpdate) {

        Set<Id> licenseModuleProductIds = new Set<Id>();
        for (SBQQ__Subscription__c subLm : Trigger.new) {
            if (subLm.SBQQ__Product__c != null) {
                licenseModuleProductIds.add(subLm.SBQQ__Product__c);
            }
        }

        Set<Id> productsWithNexusApplication = new Set<Id>();
        if (!licenseModuleProductIds.isEmpty()) {
            for (Product2 p : [
                SELECT Id
                FROM Product2
                WHERE Id IN :licenseModuleProductIds
                  AND Nexus_Application__c != null
            ]) {
                productsWithNexusApplication.add(p.Id);
            }
        }

        List<SBQQ__Subscription__c> nexusApplicationSubs = new List<SBQQ__Subscription__c>();
        for (SBQQ__Subscription__c subLm : Trigger.new) {
            if (subLm.SBQQ__Product__c != null
                    && productsWithNexusApplication.contains(subLm.SBQQ__Product__c)) {
                nexusApplicationSubs.add(subLm);
            }
        }

        if (!nexusApplicationSubs.isEmpty()) {
            try {
                if (Trigger.isInsert) {
                    LicenseModuleManager.handleSubscriptionInsert(nexusApplicationSubs);
                } else if (Trigger.isUpdate) {
                    LicenseModuleManager.handleSubscriptionUpdate(
                        nexusApplicationSubs,
                        Trigger.oldMap
                    );
                }
            } catch (Exception e) {
                System.debug(
                    LoggingLevel.ERROR,
                    'LicenseModuleManager failed: ' + e.getMessage() +
                    '\n' + e.getStackTraceString()
                );
            }
        }
    }
}
    
    if(trigger.isAfter && trigger.isUpdate){
        set<Id> contractIds = new set<Id>();
         set<Id> SubscriptionIDs= new set<Id>();
        // SFDEV-967 For Contract Primary Product update logic
        Map<Id, String> contractIdsWithPrimProductMap = new Map<Id, String>();
        
        List<SBQQ__Subscription__c> subscriptionList = new List<SBQQ__Subscription__c>();
        for(SBQQ__Subscription__c sub : trigger.new){
            if(sub.SBQQ__NetPrice__c != trigger.oldMap.get(sub.Id).SBQQ__NetPrice__c)
            {  
               contractIds.add(sub.SBQQ__Contract__c); 
                
               // Store existing PrimaryProduct__c in the map to compare during update
               contractIdsWithPrimProductMap.put(sub.SBQQ__Contract__c,sub.SBQQ__Contract__r.PrimaryProduct__c);
            }
        }
         
      
      if(!contractIds.isEmpty() && contractIds.size()>0){
            SubscriptionTriggerHandler.contractACVUpdate(contractIds);         
        }       

        
         //SubscriptionTriggerHandler.handleAfterUpdate(Trigger.new, Trigger.oldMap);
        for(SBQQ__Subscription__c sub : Trigger.new){
            Map<id,SBQQ__Subscription__c> oldSub = Trigger.oldMap;
            subscriptionList.add(sub);
            
            SBQQ__Subscription__c oldSubscription = Trigger.oldMap.get(sub.Id);
            if (oldSubscription != null && oldSubscription.SBQQ__TerminatedDate__c != sub.SBQQ__TerminatedDate__c) {
                contractIds.add(sub.SBQQ__Contract__c);
            }
            if (sub.SBQQ__TerminatedDate__c != null  && oldSubscription.SBQQ__TerminatedDate__c != sub.SBQQ__TerminatedDate__c) {
                SubscriptionIDs.add(sub.Id);
            }
        }
        if(!subscriptionList.isEmpty()){
            SubscriptionTriggerHandler.UpdatePrimaryProductTopARR(subscriptionList);
        }
        
         // SFDEV - 1155 Moving code here after Account PrimaryProductTopARR__c is updated from above function
         // SFDEV - 967 - Handle Contract Primary Product update logic
         if(!contractIdsWithPrimProductMap.isEmpty() && contractIdsWithPrimProductMap.size()>0){          
            ContractPrimaryProductHandler.updatePrimaryProductOnContract(contractIdsWithPrimProductMap);
        }  

        if (!contractIds.isEmpty()) {
            SubscriptionTriggerHandler.updateLicensesForChangedSubscriptions(contractIds);
        }
        if (!SubscriptionIDs.isEmpty()) {
            Set<Id> terminatedNexusSubIds = new Set<Id>();
            for (SBQQ__Subscription__c termSub : [
                SELECT Id
                FROM SBQQ__Subscription__c
                WHERE Id IN :SubscriptionIDs
                  AND SBQQ__Product__c != null
                  AND SBQQ__Product__r.Nexus_Application__c != null
            ]) {
                terminatedNexusSubIds.add(termSub.Id);
            }
            if (!terminatedNexusSubIds.isEmpty()) {
                LicenseModuleManager.updateLicensesModuleForTerminatedSubscriptions(
                    terminatedNexusSubIds);
            }
        }
       
    } 
    


    // Execute only if the RenewalUplift trigger switch is activated
if (TriggerSwitchCache.isTriggerActive('RenewalUplift')) {

    // Handle BEFORE trigger context 
    if (Trigger.isBefore) {

        // Handle logic before inserting new Subscriptions
        if (Trigger.isInsert) {
            // Process new subscriptions before they are inserted
            SubscriptionTriggerHandler.handleBeforeInsert(Trigger.new);
        }

        // Handle logic before updating existing Subscriptions
        if (Trigger.isUpdate) {
            // Process updates to subscriptions before they are committed
            SubscriptionTriggerHandler.handleBeforeUpdate(Trigger.new, Trigger.oldMap);
            
            // Track contracts where the override uplift rate has changed
            Set<Id> contractIds = new Set<Id>();
            for (SBQQ__Subscription__c sub : Trigger.new) {
                // Check if Override_Uplift_Rate__c value has been changed
                if (sub.Override_Uplift_Rate__c != Trigger.oldMap.get(sub.Id)?.Override_Uplift_Rate__c) {
                    contractIds.add(sub.SBQQ__Contract__c);
                }
            }

           
        }
    }

    // Handle AFTER trigger context
    if (Trigger.isAfter) {

        // Handle logic after inserting new Subscriptions
        if (Trigger.isInsert) {
            // Initialize a set to collect related Contract IDs
            Set<Id> contractIds = new Set<Id>();

            // Map to store processed Subscriptions by their IDs
            Map<Id, SBQQ__Subscription__c> processedSubsMap = new Map<Id, SBQQ__Subscription__c>();

            // Loop through new subscriptions to gather contracts for processing
            for (SBQQ__Subscription__c sub : Trigger.new) {
                // Only consider subscriptions linked to a contract
                if (sub.SBQQ__Contract__c != null) {
                    contractIds.add(sub.SBQQ__Contract__c);
                    processedSubsMap.put(sub.Id, sub);
                }
            }

            // If contracts are identified, update their effective uplift rates
            if (!contractIds.isEmpty()) {
                SubscriptionTriggerHandler.updateContractEffectiveUpliftRates(contractIds, processedSubsMap);
            }
        }
    }
}

}