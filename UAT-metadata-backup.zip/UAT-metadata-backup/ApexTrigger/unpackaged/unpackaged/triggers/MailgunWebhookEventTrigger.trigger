/**
 * @description Platform Event trigger that reconciles Mailgun delivery status back onto billing records.
 *
 *              Fires {@code after insert} on the {@code Mailgun_Webhook_Event__e} platform event, which is
 *              published by {@code MailgunWebhookService} when Mailgun calls the inbound webhook. The trigger
 *              simply forwards the batch of received events to {@link MailgunWebhookEventHandler#process},
 *              which matches each event's Mailgun message id to the originating Account, Invoice, or Credit
 *              Memo and stamps the latest {@code Email_Delivery_Status__c}. All matching and DML logic lives
 *              in the handler, keeping the trigger a thin, logic-free dispatcher.
 *
 * @author Satheesh Sivakumar
 * @since 2026-07-03
 * @group  Automated Document Delivery
 * @see    MailgunWebhookEventHandler
 * @see    MailgunWebhookService
 */
trigger MailgunWebhookEventTrigger on Mailgun_Webhook_Event__e (after insert) {
    System.debug(LoggingLevel.INFO, '#001 MailgunWebhookEventTrigger - Trigger started');
    MailgunWebhookEventHandler.process(Trigger.New);

}