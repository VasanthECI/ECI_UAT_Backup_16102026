/**
 * @description Single trigger on Journal_Deadlock__c; no logic here.
 * @see JournalDeadlockTriggerHandler
 */
trigger JournalDeadlockTrigger on Journal_Deadlock__c (before update) {
    JournalDeadlockTriggerHandler.beforeUpdate(Trigger.new, Trigger.oldMap);
}