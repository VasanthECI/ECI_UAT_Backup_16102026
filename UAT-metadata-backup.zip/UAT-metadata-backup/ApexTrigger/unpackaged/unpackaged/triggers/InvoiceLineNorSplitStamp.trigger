trigger InvoiceLineNorSplitStamp on InvoiceLine (before insert) {
    for (InvoiceLine line : Trigger.new) {
        if (line.Name == 'NOR split test') {
            line.Revenue_Category__c = 'On Prem Subscription';
            line.LegalEntityId = '0fwVE0000001uf9YAA';
            line.LegalEntityAccountingPeriodId = '1HLVE0000000xm14AA';
        }
    }
}