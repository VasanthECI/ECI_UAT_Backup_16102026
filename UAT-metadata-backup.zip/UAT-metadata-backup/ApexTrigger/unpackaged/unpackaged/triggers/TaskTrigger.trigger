trigger TaskTrigger on Task (after insert,after update) {
    
    if(!TriggerSwitchUtility.isTriggerActivated('Task')){
        System.debug('Task Trigger disabled');
        return;    
    }
	
    if(trigger.isAfter){
    	List<Task> queueTasks = new List<Task>();
        map<Id, Task> taskMap = new map<Id, Task>();
        TaskTriggerHandler.accountUpdate(trigger.new,trigger.oldmap);
        if(trigger.isInsert){
            for(Task t : trigger.new){
                String ownerId =t.ownerId;
                if(ownerId.startsWith('00G')){
                	queueTasks.add(t); 
                    taskMap.put(t.Id,t);
                }    
            }  
            //TaskTriggerHandler.accountUpdate(trigger.new,trigger.oldmap);
        }
        else if(trigger.isUpdate){
        	for(Task t : trigger.new){
                String ownerId =t.ownerId;
                if(ownerId.startsWith('00G') && ownerId !=trigger.oldMap.get(t.Id).ownerId){
                	queueTasks.add(t);  
                    taskMap.put(t.Id,t);
                }    
            }
              
            //TaskTriggerHandler.accountUpdate(trigger.new,trigger.oldmap);
        }
        if(queueTasks.size() >0){
            TaskTriggerHandler.notifyQueueMembers(queueTasks, taskMap);
        }
    }
    
}