/**
 * @description Trigger on `PO_Receipt_Line_Item__c`. Per the project standard, contains no
 *              business logic — routes after-insert/update to
 *              `PO_ReceiptLineItemTriggerHandler.afterInsertOrUpdate`.
 *
 * @author      Michael Morrell
 * @version     1.0
 * @since       2026-05-19
 * @see         PO_ReceiptLineItemTriggerHandler
 */
trigger PO_ReceiptLineItemTrigger on PO_Receipt_Line_Item__c (after insert, after update) {
    if (Trigger.isAfter && (Trigger.isInsert || Trigger.isUpdate)) {
        PO_ReceiptLineItemTriggerHandler.afterInsertOrUpdate(Trigger.new);
    }
}