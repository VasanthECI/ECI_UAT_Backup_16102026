trigger UpdateCaseStatusOnFeed on FeedItem (before insert,after insert) {
    System.debug('Feed Item Trigger');
    // Added as part of Ticket 543 to throw error when Activity added on Closed cases
    if(trigger.isBefore){
        if(trigger.isInsert){
         	CaseServices.validateCommentsAndFeed(trigger.new, new List<FeedComment>());
        }    
    }else{
   		CaseServices.updateCaseStatusOnFeed(trigger.new);     
    }
    

}