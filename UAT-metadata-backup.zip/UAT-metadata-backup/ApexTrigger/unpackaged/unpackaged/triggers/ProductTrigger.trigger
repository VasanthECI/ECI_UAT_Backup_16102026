/**
* Trigger Name: ProductTrigger
* Description: Trigger that handles changes related to the standard 
Product object.
* Author: Madhumitha
* Date Created: 10/23/2025
* Version History:
*
* Version : 1.1
* Author  : Madhumitha
* Changes : SFDEV-1522 - Added handleAfterUpdate to sync PricebookEntry IsActive during Product activation/deactivation
* Date    : 02/02/2026
*
* Version : 1.0
* Author  : Madhumitha
*/

trigger ProductTrigger on Product2 (before update,after update) {
    
    // Check if the Product trigger is deactivated in the TriggerSwitchCache; exit if disabled
     if(!TriggerSwitchCache.isTriggerActive('Product')){
        System.debug('Product Trigger was disabled');
        return;    
    }
    
     if (Trigger.isBefore && Trigger.isUpdate) {
        ProductTriggerHandler.handleBeforeUpdate(Trigger.new, Trigger.oldMap);
    }
    //SFDEV-1522 - Handles after update logic for Product2 
    if (Trigger.isAfter && Trigger.isUpdate) {
        ProductTriggerHandler.handleAfterUpdate(Trigger.new, Trigger.oldMap);
    } 
}