/**
 * @description Trigger on `PO_Line_Item__c`. Per the project standard, contains no business
 *              logic — routes after-insert to `PO_LineItemTriggerHandler.afterInsert`.
 *
 *              <p><b>Scope is after-insert only.</b> Per architecture doc A2,
 *              `Opportunity_Product__c` is reliably populated at PO line creation in flows
 *              where fulfillment is required, so the bridge resolves once at insert and
 *              never needs to re-fire. PO lines edited later to set
 *              `Opportunity_Product__c` for the first time are an accepted gap
 *              (architecture doc §4.5).
 *
 * @author      Michael Morrell
 * @version     1.1
 * @since       2026-05-19
 * @see         PO_LineItemTriggerHandler
 */
trigger PO_LineItemTrigger on PO_Line_Item__c (after insert) {
    if (Trigger.isAfter && Trigger.isInsert) {
        PO_LineItemTriggerHandler.afterInsert(Trigger.new);
    }
}