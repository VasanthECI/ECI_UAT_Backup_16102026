/**
* Class Name: CaseTrigger
* Description:
* 
* Author: 
* Date Created: 
* Last Modified: 
* 
* Version : 1.4 
* Author  : Aruljothi
* Changes : Added logic to conditionally skip trigger execution for specific users.
*           The excluded users are configured via the custom label
*           'ECI_Ally_Guest_User'. If the current user's ID is found in the
*           label-defined exclusion list, the PeeklogicCaseTriggerHelper
*           is not executed. 
* Date    : 05/02/2026

* Version History:
* Version : 1.3
* Author  : Madhumitha
* Changes : SFDEV-1327 - Update Project banner on Case Delete and RecordType change
* Date    : 15/Dec/2025
*
* Version : 1.2
* Author  : Vidhya
* Changes : SFDEV-1192 - Case-Project fields synchronization.
* Date    : 17/Sep/2025

* Version : 1.1 
* Author  : Vasanth
* Changes : Update the logic to automatically send a response for child cases.
* Date    : 01/04/2025



*/
trigger CaseTrigger on Case (before delete, before insert, before update,
                             after delete,  after insert,  after update)
{
    // 1192 - To handle recursion on Case-Project synchronization
    if(CaseProjectSyncHandler.IsProjectUpdating){
        return;
    }
    CaseProjectSyncHandler.IsCaseUpdating = true;
    
    if (Trigger.isBefore) {
        if(Trigger.isInsert || Trigger.isUpdate) {
            // SFDEV-1327 - Clear tracking set at start of transaction
            CaseProjectSyncHandler.projectsNeedingBannerUpdate.clear();
            
            // Set ShowSyncBanner__c flag for cases with projects that have multiple cases
            CaseProjectSyncHandler.validateCaseProjectToShowBannerInCase(trigger.new, trigger.oldMap);
            
            // Handle cases where Project__c has changed - update case fields from new project
            // Also populates projectsNeedingBannerUpdate for RecordType/Project changes
            Set<Id> casesWhereProjectChanged = CaseProjectSyncHandler.handleIfProjectHasChanged(trigger.new, trigger.oldMap);
            CaseProjectSyncHandler.casesWhereProjectChanged = casesWhereProjectChanged;
        }
    }
       
    if (Trigger.isAfter) {
        // Insert/Update: Sync case fields to project + update project banners
        if(Trigger.isInsert || Trigger.isUpdate) {
            CaseProjectSyncHandler.syncCaseToProject(trigger.new, trigger.oldMap, CaseProjectSyncHandler.casesWhereProjectChanged);
            CaseProjectSyncHandler.updateProjectBannersIfNeeded();
        }
        
        // Delete: Collect projects from deleted cases + update project banners
        if (Trigger.isDelete) {
            CaseProjectSyncHandler.collectProjectsFromDeletedCases(Trigger.old);
            CaseProjectSyncHandler.updateProjectBannersIfNeeded();
        }
    }
    // End of 1192 / SFDEV-1327
    
    if(!TriggerSwitchUtility.isTriggerActivated('CaseSpamDetection')){
        if (Trigger.isAfter && Trigger.isInsert) {
            CaseTriggerHelper.processIncomingEmails(Trigger.new);
        }}
    if(TriggerSwitchUtility.isTriggerActivated('CaseSpamDetection')){
        if (Trigger.isAfter) {
            if (Trigger.isInsert) {
                List<Case> communityCases = new List<Case>();
                for (Case cs : Trigger.new) {
                    if (cs.Origin == 'Community') 
                    {
                        communityCases.add(cs);
                    }
                    
                }
                if (!communityCases.isEmpty()) {
                    CaseTriggerHelper.processIncomingEmails(communityCases);
                }
            }
            // Send an automatic response for the child case
            if (Trigger.isInsert) {
                List<Case> childCases = new List<Case>();
                for (Case cs : Trigger.new) 
                {
                    if (cs.Origin == 'Email' && cs.SPAM_Status__c == 'NOT_SPAM' ) 
                    {
                        childCases.add(cs);
                    }
                }
                if (!childCases.isEmpty()) 
                {
                    CaseTriggerHelper.processIncomingEmails(childCases);
                }
            }
            
            if (Trigger.isUpdate) {
                List<Case> emailCases = new List<Case>();
                for (Case cs : Trigger.new) {
                    Case oldCase = Trigger.oldMap.get(cs.Id);
                    if (cs.Origin == 'Email' && cs.SPAM_Status__c == 'NOT_SPAM' && cs.SPAM_Status__c != oldCase.SPAM_Status__c) {
                        emailCases.add(cs);
                    }
                }
                if (!emailCases.isEmpty()) {
                    CaseTriggerHelper.processIncomingEmails(emailCases);
                    
                }
            }
        }
    }
    
    if(!TriggerSwitchUtility.isTriggerActivated('Case')){
        System.debug('Case Trigger disabled');
        return;    
    }
    system.debug('executing case trigger');
    if (Trigger.isBefore) {
        //Solunus added code from line 6 to 52
        //@description : Logic is to update Entitlements and Business Hours based on the tied to Account geo
        list<Id> accountIds = new list<Id>();
        Map<Id,Account>  accountMap = new Map<Id,Account>();
        if(trigger.isInsert || Trigger.isUpdate)
        {
            for(case caseRec : trigger.new)
            {
                accountIds.add(caseRec.AccountId);
            }
            for(Account accountRec : [Select id,Name,BillingGeo__c from Account where Id IN : accountIds])
            {
                accountMap.put(accountRec.Id,accountRec);
            }
            Map<String,Entitlement_Ids__mdt> entitlementsMap = new Map<String,Entitlement_Ids__mdt>();
            list<Entitlement_Ids__mdt> entitlments = [SELECT MasterLabel,Business_Hours__c,QualifiedApiName,Entitlement_Id__c FROM Entitlement_Ids__mdt];
            for(Entitlement_Ids__mdt entitlment : entitlments)
            {
                entitlementsMap.put(entitlment.MasterLabel,entitlment);
            }
            
            map<Id,RecordType> recmap=new map<id,RecordType>([SELECT Id, Name, DeveloperName, IsActive, SobjectType FROM RecordType where name='Accounting' or name='Project']);
            
            for(Case caseVar : trigger.new)
            {
                if(!recmap.containskey(caseVar.RecordTypeId)){
                    //Setting Case priority to P4 when priority is null
                    if(caseVar.Priority== NULL){
                        try{
                            //caseVar.Priority='P4';
                        } catch(QueryException ex) {
                            
                        }
                    }
                    if(caseVar.AccountId == Null)
                    {
                        caseVar.EntitlementId=entitlementsMap.get('v11 Americas').Entitlement_Id__c;
                        caseVar.BusinessHoursId = entitlementsMap.get('v11 Americas').Business_Hours__c;
                    }
                    else if(accountMap.get(caseVar.AccountId).BillingGeo__c == 'EMEA')
                    {
                        caseVar.EntitlementId=entitlementsMap.get('v11 EMEA').Entitlement_Id__c;
                        caseVar.BusinessHoursId = entitlementsMap.get('v11 EMEA').Business_Hours__c;
                    }
                    else if(accountMap.get(caseVar.AccountId).BillingGeo__c == 'APAC')
                    {
                        caseVar.EntitlementId=entitlementsMap.get('v11 APAC').Entitlement_Id__c;
                        caseVar.BusinessHoursId = entitlementsMap.get('v11 APAC').Business_Hours__c;
                    }
                    else if(accountMap.get(caseVar.AccountId).BillingGeo__c == 'Americas')
                    {
                        caseVar.EntitlementId=entitlementsMap.get('v11 Americas').Entitlement_Id__c; 
                        caseVar.BusinessHoursId = entitlementsMap.get('v11 Americas').Business_Hours__c;
                    }
                }
            }
        }
        if(Trigger.isUpdate){
            //Added as part of ticket 543 to track from which recordtype the case is closed
            if(!CaseTriggerhelperClass.recordTypeFlag && !system.isFuture()){ 
                CaseTriggerhelperClass.updateCase(trigger.new, trigger.oldMap);  
            }
            /*if(!CaseTriggerhelperClass.closedCaseFlag){
CaseTriggerhelperClass.validateClosedCases(trigger.new, trigger.oldMap);    
}*/
            for (Case newCase: trigger.new) {
                Case oldCase = trigger.oldMap.get(newCase.Id);
                V1API.sendCaseUpdate(oldCase, newCase);
                //V1API.updateNumberFields(newCase);
            }
        }
        
        list<case> newCases = new list<case>();
        if(!Trigger.isDelete){
            for(Case c : Trigger.new){
                if(Trigger.isInsert || (Trigger.isUpdate && c.product__c != trigger.oldMap.get(c.id).product__c)){
                    newCases.add(c);
                }
            }
            if(newCases.size()>0){
                CaseTriggerHelperClass.updateCaseDivision(newCases);
            }
        }
    }
    
    else {
        if(Trigger.isDelete){
            
        } 
        else {
            List<ID> reassignCases = new List<ID>();
            for(Case c : Trigger.new){
                string owner = c.ownerid;
                // PMD-justification: skip assignment rules for Omni skills-routed cases and
                // any queue-owned case so routing hold / fallback queues are not reclaimed.
                if (c.Skills_Routed__c == true) {
                    continue;
                }
                if (owner != null && owner.startsWith('00G')) {
                    continue;
                }
                if(c.RunAssignmentRules__c && ((trigger.isInsert && !owner.StartsWith('00G')) || (Trigger.isUpdate && c.RunAssignmentRules__c != trigger.oldMap.get(c.id).RunAssignmentRules__c))){
                    reassignCases.add(c.id);
                }
            }
            if(reassignCases.size()>0 && !System.isFuture() && !DMLOpt.booleanflag){
                DMLOpt.autoAssignCase(reassignCases);
                DMLOpt.booleanflag = true;
            }
            
        }
        if (Trigger.isInsert) {
            Set<Id> caseIds = New Set<Id>();
            CaseTriggerHelper.updateMilestoneTimes(Trigger.new);
            id recTypeId = Schema.SObjectType.Case.getRecordTypeInfosByName().get('Support').getRecordTypeId();
            List<CaseTeamMember> caseTeamToAdd = new List<CaseTeamMember>();
            List<CaseTeamRole> roleList = [SELECT ID, Name FROM CaseTeamRole WHERE Name='Agent'];
            for(Case c : Trigger.new){
                if(c.recordtypeId == recTypeId && c.ContactId == null){
                    caseIds.add(c.id);
                }
                if(roleList.size()>0 && String.valueOf(c.OwnerId).startsWith('005')){
                    caseTeamToAdd.add(new CaseTeamMember(ParentId=c.Id,TeamRoleId=roleList[0].Id,
                                                         MemberId=c.OwnerId));
                }
            }
            if(caseTeamToAdd.size()>0 && UserInfo.getUserType()=='Standard'){
                
                // Disabled the automation responsible for adding case team members to the related case during creation and updates,
                //  as part of the Jira story SFDEV-817.               
                //   INSERT caseTeamToAdd;
            }
            if(!caseIds.isEmpty()){
                CaseTriggerHelper.updatePreChatHistory(caseIds);
            }
        }
        if(Trigger.isUpdate){
            if(!system.isFuture()){
                system.debug('after update :: updating milestonesTimes');
                CaseTriggerHelper.updateMilestoneTimes(Trigger.new);
                CaseTriggerhelperClass.updateMilestoneTracker(Trigger.new,Trigger.oldmap);
                // Take new cases, bulkified
                map<Id,Case> caseMap = new map<Id,Case>();
                for(Case c : trigger.new){
                    if(c.OwnerId != trigger.oldMap.get(c.Id).ownerId && String.valueOf(c.OwnerId).startsWith('005')){
                        System.debug('case owner::'+c.ownerId);
                        caseMap.put(c.Id, c);    
                    }    
                }
                if(caseMap.size() >0){
                    //CaseTriggerhelperClass.createCaseTeams(caseMap);   
                }
            }
            Set<Id> caseIds = New Set<Id>();
            for(case c : trigger.new){ 
                if(c.Product__c != trigger.oldmap.get(c.id).Product__c && c.Product__c != Null){
                    caseIds.add(c.id);
                    system.debug('after update ');
                }
            }
            if(!caseIds.isEmpty()){
                CaseTriggerhelperClass.updateDivision(caseIds);
            }
            
            /*
list<String> caseIds = new list<String>();
For(case caseRec : trigger.New)
{

if(caseRec.status != trigger.oldMap.get(caseRec.id).status &&(caseRec.Status =='In Dev' || caseRec.Status =='Closed' || caseRec.Status =='Resolved'))
caseIds.add(caseRec.Id);
}
list<CaseMilestone> milestoneList = new list<CaseMilestone>();
for(CaseMilestone milestone : [select id,CompletionDate from CaseMilestone where caseId IN : caseIds])
{
milestone.CompletionDate = system.now();
milestoneList.add(milestone);
}
update milestoneList;
*/
        }
        
    }
    //Enhancement Request:
    //We would like to request an enhancement that when a Salesforce status moves to "Closed" or "Reopened" that a comment get added to the Jira ticket.
    // Comment to read as "Salesforce case status was updated to Closed/Reopened by user ____ (display sf user name)"
    
    // Check if current user is NOT in the ECI_Ally_Guest_User custom label (exclude these users)
    String excludedUserIds = '';
    try {
        excludedUserIds = Label.ECI_Ally_Guest_User;
    } catch (Exception e) {
        System.debug('Custom label ECI_Ally_Guest_User not found or error: ' + e.getMessage());
    }
    
    Set<String> excludedUserIdSet = new Set<String>();
    if(String.isNotBlank(excludedUserIds)) {
        for(String userId : excludedUserIds.split(',')) {
            if(String.isNotBlank(userId)) {
                excludedUserIdSet.add(userId.trim());
            }
        }
    }
    
    String currentUserId = UserInfo.getUserId();
    System.debug('Current User ID: ' + currentUserId);
    System.debug('Excluded User IDs: ' + excludedUserIdSet);
    System.debug('Is current user excluded? ' + excludedUserIdSet.contains(currentUserId));
    
    // Only run trigger handler if current user is NOT in the excluded list
    if(!excludedUserIdSet.contains(currentUserId)) {
        System.debug('Running PeeklogicCaseTriggerHelper for user: ' + currentUserId);
        fflib_SObjectDomain.triggerHandler(PeeklogicCaseTriggerHelper.class);
    } else {
        System.debug('Skipping PeeklogicCaseTriggerHelper for excluded user: ' + currentUserId);
    }
    // 1192 - To handle recursion on Case-Project synchronization
    CaseProjectSyncHandler.IsCaseUpdating = false;

}