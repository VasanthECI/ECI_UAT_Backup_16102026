/**
 * @description Trigger on `Project_Provisioned__e`. Per the project standard, triggers
 *              contain no business logic; they only route trigger context to a handler
 *              class. All dispatch and per-subscriber error isolation lives in
 *              `ProjectProvisionedTriggerHandler.afterInsert`.
 *
 * @author      Michael Morrell
 * @version     1.0
 * @group       OpportunityServices
 * @see         ProjectProvisionedTriggerHandler
 */
trigger ProjectProvisionedTrigger on Project_Provisioned__e (after insert) {
    if (Trigger.isAfter && Trigger.isInsert) {
        ProjectProvisionedTriggerHandler.afterInsert(Trigger.new);
    }
}