/* - - - - - - - - - - - - - - - - - - - - - -
* JIraIssueTrigger
* - - - - - - - - - - - - - - - - - - - - - - 
* Author: Peeklogic
* www.peeklogic.com
* - - - - - - - - - - - - - - - - - - - - - -
* Test Coverage:
*  JIraIssueTrigger_Test 100%
*Last Modified: 03/04/2025
* - - - - - - - - - - - - - - - - - - - - - -
* Version History:
* Version : 1.0
* Author  : ibegei@peeklogic.com
* Changes :  
* Date    : 03/04/2025
*/

trigger JIraIssueTrigger on peeklogic_jc__Jira_Issue__c (after insert, after update, before delete) {
    public static  peeklogic_jc__Jira_Admin_Settings__c settings { 
        get {
            if ( settings == null ){
                settings=peeklogic_jc__Jira_Admin_Settings__c.getOrgDefaults(); 
            } 
            return settings;
        } private set; }
    if(!settings.Disable_Jira_Issue_Trigger__c ){
        fflib_SObjectDomain.triggerHandler(JiraIssueTriggerHandler.class);
    }
    
}