/**
* Class Name: Opportunity
* Description: Single trigger on Opportunity. Pure dispatcher — all logic lives in
*              OpportunityTriggerHelper.handle().
* 
* Author: 
* Date Created: 
* Last Modified: 
* 
* Version History:
* Version : 1.1
* Author  : Surya
* Changes : Commented out helper.onBeforeInsert(Trigger.new[0]); as the logic is now handled by Flows, making the old code no longer needed. 
* Date    : 6/27/2025

* Version History:
* Version : 1.2
* Author  : Surya
* Changes : Added logic to prevent removal of the AccountId on Opportunities that are related to Amendments, Renewals, or have a Primary Quote.
* Date    : 3/23/2026
*
* Version History:
* Version : 1.3
* Author  : Michael Morrell
* Changes : Added (after update / IsWon false->true -> OpportunityService.createCertiniaProject) to trigger PS 1:1:1 logic. 
*           Cached trigger.oldMap.get(o.Id) into a local to remove repeated map lookups. Removed two leftover System.debug statements.
* Date    : 5/4/2026
*
* Version : 1.4
* Author  : Michael Morrell
* Changes : Closed Won PO creation now publishes Opportunity_Closed_Won_PO__e (ClosedWonPoPublisherService)
*           instead of synchronous OpportunityClosedWonPurchaseOrderHandler DML on the Opp save path.
* Date    : 6/1/2026
*
* Version : 1.5
* Author  : Michael Morrell
* Changes : Closed Won PO provisioning enqueues ClosedWonPoProvisioningQueueable (no platform event).
* Date    : 6/1/2026
*
* Version : 1.6
* Author  : Michael Morrell
* Changes : Closed Won Certinia project provisioning moved async. Before insert/update stamps
*           Provision_Projects_Pending__c on Won opps; after insert/update enqueues
*           ClosedWonProjectProvisioningQueueable. Hourly ClosedWonProjectProvisioningBatch retries
*           anything still pending. Removed synchronous OpportunityService.createCertiniaProject.
* Date    : 7/8/2026
*
* Version : 1.7
* Author  : Michael Morrell
* Changes : Trigger reduced to single helper dispatch (no inline logic) for PMD AvoidLogicInTrigger /
*           complexity compliance. Behavior unchanged — body moved to OpportunityTriggerHelper.handle().
* Date    : 7/9/2026
*/
trigger Opportunity on Opportunity (after delete, after insert, after undelete, after update, before delete, before insert, before update) {
    OpportunityTriggerHelper.handle();
}