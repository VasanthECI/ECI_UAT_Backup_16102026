trigger EntitlementToCase on Case (before update) {
    /*List<Account> AccIds = New List <Account>();
 for (Case c : Trigger.new) {
        if (c.Entitlement_Case__c == True) {
            try{
                 c.EntitlementId = [Select Id from Entitlement Where Status ='Active' and AccountId = :c.AccountId].Id;
                 c.AccountId = [Select Id from Account Where Id = :c.AccountId].id;
            }catch(QueryException ex) {
           
            }
        AccIds.add(c.Account);
        }
 }
List<Account> AccList = [Select id FROM Account WHERE id in :AccIds];
    for(integer i = 0; i < AccList.size(); i++){
        
    }
//update AccList;


*/
}