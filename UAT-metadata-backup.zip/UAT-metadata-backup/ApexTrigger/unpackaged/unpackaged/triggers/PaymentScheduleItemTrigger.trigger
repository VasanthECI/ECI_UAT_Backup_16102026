/**
 * @description Trigger on {@link PaymentScheduleItem}. Before insert stamps
 *              {@link PaymentScheduleItem.AutoPay__c}. After update routes status
 *              changes to {@link PaymentScheduleItemTriggerHandler#afterUpdate}.
 *
 * @author  Vidhya
 * @since   2026-07-29 v1.0 Initial Payment Run status-change routing
 * @see     PaymentScheduleItemTriggerHandler
 */
trigger PaymentScheduleItemTrigger on PaymentScheduleItem (before insert, after update) {
    if (Trigger.isBefore && Trigger.isInsert) {
        PaymentScheduleItemAutoPayService.stampAutoPayOnInsert(Trigger.new);
    }
    if (Trigger.isAfter && Trigger.isUpdate) {
        PaymentScheduleItemTriggerHandler.afterUpdate(Trigger.new, Trigger.oldMap);
    }
}