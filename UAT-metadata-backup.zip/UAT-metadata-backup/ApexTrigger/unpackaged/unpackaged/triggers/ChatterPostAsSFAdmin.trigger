/**
* Class Name: ChatterPostAsSFAdmin
* Description: This trigger listens for inserted Chatter_Post_Event__e platform events and create Chatter posts as the Salesforce Admin user.
* 
* Author: surya
* Date Created: 27/3/2025
* Last Modified: 
* 
* Version History:
* Version : 
* Author  : 
* Changes : 
* Date    : 
*/

trigger ChatterPostAsSFAdmin on Chatter_Post_Event__e (after insert) {
    System.debug('Trigger ChatterPostAsSFAdmin fired. Total records: ' + Trigger.new.size());
    
    if (Trigger.isAfter && Trigger.isInsert) {
        List<ChatterPostSFAdminHandler.ChatterPostRequest> requests = new List<ChatterPostSFAdminHandler.ChatterPostRequest>();

        for (Chatter_Post_Event__e eventRecord : Trigger.new) {
            System.debug('Processing event record: ' + eventRecord);

            // Ensure field names match the platform event definition
            ChatterPostSFAdminHandler.ChatterPostRequest req = new ChatterPostSFAdminHandler.ChatterPostRequest();
            req.OwnerId = eventRecord.Owner_Id__c;
            req.ManagerId = eventRecord.Manager_Id__c; // Fixed typo
            req.ParentId = eventRecord.Parent_Id__c;
            req.CaseNumber = eventRecord.Case_Number__c;
            req.CommunityUserName = eventRecord.Community_User_Name__c;
            
            System.debug('Constructed ChatterPostRequest: ' + req);
            requests.add(req);
        }

        if (!requests.isEmpty()) {
            System.debug('Calling postChatterMessage with ' + requests.size() + ' requests.');
            ChatterPostSFAdminHandler.postChatterMessage(requests);
        } else {
            System.debug('No valid requests to process.');
        }
    }
}