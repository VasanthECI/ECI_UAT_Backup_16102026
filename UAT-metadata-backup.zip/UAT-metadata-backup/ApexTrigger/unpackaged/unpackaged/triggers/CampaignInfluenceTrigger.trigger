/**
* Class Name: CampaignInfluenceTrigger
* Description:
* 
* Author: 
* Date Created: 
* Last Modified: 02/13/2025
* 
* Version History:
* Version : 1.2 
* Author  : vasanth
* Changes : The API changed from 'Opportunity_SV__c' to 'OSV_C'. 
* Date    : 02/06/2025
*/

trigger CampaignInfluenceTrigger on CampaignInfluence (before insert, after insert, before update, after update) {
    //CampaignInfluenceTriggerHandler util = new CampaignInfluenceTriggerHandler(trigger.new, trigger.old, trigger.newMap, trigger.oldMap);
    
    if(trigger.isAfter){
        if(trigger.isInsert){
            Map<Id, CampaignInfluence> oppIdtoCi = new Map<Id, CampaignInfluence>();
            for(CampaignInfluence ci : trigger.new){
                if(ci.OpportunityId != null){
                    oppIdtoCi.put(ci.OpportunityId, ci);
                }
            }
            
            //List<Opportunity> influencedOpps = [SELECT Id, First_Associated_Campaign_Influence__c,OpportunitySkipValidation__c FROM Opportunity WHERE Id IN :oppIdtoCi.keySet()];
     List<Opportunity> influencedOpps = [SELECT Id, First_Associated_Campaign_Influence__c,OSV__c FROM Opportunity WHERE Id IN :oppIdtoCi.keySet() AND type != 'Data Migration'];

            List<Opportunity> oppsToUpdate = new List<Opportunity>();
            for(Opportunity opp : influencedOpps){
                //opp.MQL_Date__c = Date.today();
                if(opp.First_Associated_Campaign_Influence__c == null){
                    opp.First_Associated_Campaign_Influence__c = oppIdtoCi.get(opp.Id).CampaignId;
                    opp.Has_Campaign_Influence__c = true;
                    if(opp.OSV__c){
                        opp.OSV__c=False;
                    }
                    else{
                        opp.OSV__c=True;
                    }
                    oppsToUpdate.add(opp);
                }
            }
            if(oppsToUpdate.size()>0){
                update oppsToUpdate;
            }
        }
    }
}