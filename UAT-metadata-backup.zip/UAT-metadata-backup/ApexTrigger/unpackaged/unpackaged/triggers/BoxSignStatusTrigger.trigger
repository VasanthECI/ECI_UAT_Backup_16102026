/**
* Trigger Name: BoxSignStatusTrigger
* Description: SFDEV- 1200 - This trigger monitors Box Sign records for completion status changes. When a Box Sign request's 
  Completed__c field changes to True (indicating all signers have completed signing), it schedules a batch job 
  (BoxSignSignerUpdateBatch) to run after a 1-minute delay to update all related Box Sign Signer records' status to 'Completed'.
* 
* Author: Vasanth
* Date Created: 10/2/2026
* Last Modified: 10/2/2026
* **/

trigger BoxSignStatusTrigger on box__BoxSign__c (after update) {
    
    // List to store BoxSign IDs that changed to 'signed'
    List<Id> signedBoxSignIds = new List<Id>();
    
    // Check which records changed to 'signed' status
    for (box__BoxSign__c boxSign : Trigger.new) {
        box__BoxSign__c oldBoxSign = Trigger.oldMap.get(boxSign.Id);
        
        // Check if status changed to 'signed'
        if (boxSign.Completed__c == True && oldBoxSign.Completed__c != True) {
            signedBoxSignIds.add(boxSign.Id);
        }
    }
    
    // If there are any BoxSign records that changed to 'signed'.
    // BoxSignSyncBatch sets bypassSignerSchedule = true before updating the parent,
    // because System.scheduleBatch is illegal from a batch context and would throw
    // System.AsyncException (rolling back the parent update). That batch already
    // reconciles signer statuses, so the follow-up batch is not needed there.
    if (!signedBoxSignIds.isEmpty() && !BoxSignSyncBatch.bypassSignerSchedule) {
        // Schedule the update to run after 1 minute
        System.scheduleBatch(
            new BoxSignSignerUpdateBatch(signedBoxSignIds), 
            'BoxSign Signer Update - ' + System.now(), 
            1  // 1 minute delay
        );
    }
}