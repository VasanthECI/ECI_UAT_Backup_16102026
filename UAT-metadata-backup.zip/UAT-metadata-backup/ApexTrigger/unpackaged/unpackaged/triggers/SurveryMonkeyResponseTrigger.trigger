/**
* Class Name: SurveryMonkeyResponseTrigger
* Description: Apex to trigger the SurveyMonkeyResponsehandler class 
* 
* Author: Surya
* Date Created: 4/23/2025
* Last Modified: 6/17/2025
* 
* Version History:
* Version : 2.1
* Author  : Enhanced trigger to handle updates with field change detection
* Changes : Added oldMap parameter and update logic with field change detection
*/
trigger SurveryMonkeyResponseTrigger on SurveyMonkey_Response__c (after insert, after update) {
    
    // Check if trigger is activated
    if (TriggerSwitchUtility.isTriggerActivated('SurveyMonkey_Response__c')) {   
        
        if (Trigger.isAfter && Trigger.isInsert) {      
            try {
                System.debug('SurveryMonkeyResponseTrigger - INSERT - Processing ' + Trigger.new.size() + ' records');
                SurveyMonkeyResponsehandler.SurveyResponseTranslator(Trigger.new, null);
                
            } catch (Exception e) {
                System.debug('ERROR in SurveryMonkeyResponseTrigger (INSERT): ' + e.getMessage());
                System.debug('Stack Trace: ' + e.getStackTraceString());
            }        
        }
        
        if (Trigger.isAfter && Trigger.isUpdate) {
            try {
                System.debug('SurveryMonkeyResponseTrigger - UPDATE - Processing ' + Trigger.new.size() + ' records');
                SurveyMonkeyResponsehandler.SurveyResponseTranslator(Trigger.new, Trigger.oldMap);
                
            } catch (Exception e) {
                System.debug('ERROR in SurveryMonkeyResponseTrigger (UPDATE): ' + e.getMessage());
                System.debug('Stack Trace: ' + e.getStackTraceString());
            }
        }
    }
}