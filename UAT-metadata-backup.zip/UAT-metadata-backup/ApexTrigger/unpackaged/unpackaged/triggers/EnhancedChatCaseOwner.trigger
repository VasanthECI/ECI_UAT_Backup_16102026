trigger EnhancedChatCaseOwner on Enhanced_Chat_Case_Owner__e (after insert) {
    
    List<Case> casesToUpdate = new List<Case>();
    Set<Id> caseIds = new Set<Id>();
    Map<Id, Id> caseToNewOwnerMap = new Map<Id, Id>();
    
    // Collect all the case IDs and their new owners
    for (Enhanced_Chat_Case_Owner__e event : Trigger.new) {
        System.debug('Event received - Case: ' + event.Case_Id__c + ', New Owner: ' + event.New_Owner_Id__c);
        caseIds.add(event.Case_Id__c);
        caseToNewOwnerMap.put(event.Case_Id__c, event.New_Owner_Id__c);
    }
    
    // Query the cases to verify they exist and get current owner
    Map<Id, Case> existingCases = new Map<Id, Case>([
        SELECT Id, OwnerId, Status 
        FROM Case 
        WHERE Id IN :caseIds
    ]);
    
    System.debug('Cases found: ' + existingCases.size() + ' of ' + caseIds.size());
    
    // Prepare cases for update
    for (Id caseId : caseToNewOwnerMap.keySet()) {
        if (existingCases.containsKey(caseId)) {
            Case c = existingCases.get(caseId);
            Id newOwnerId = caseToNewOwnerMap.get(caseId);
            
            // Only update if owner is different
            if (c.OwnerId != newOwnerId) {
                casesToUpdate.add(new Case(
                    Id = caseId,
                    OwnerId = newOwnerId
                ));
            }
        }
    }
    
    // Update the cases
    if (!casesToUpdate.isEmpty()) {
        try {
            update casesToUpdate;
            System.debug('Successfully updated ' + casesToUpdate.size() + ' case(s)');
        } catch (Exception e) {
            System.debug('ERROR updating cases: ' + e.getMessage());
        }
    } else {
        System.debug('No cases to update');
    }

}