/**
 * @description Subscriber trigger on Aero_SLA_Breach__e. Thin; delegates to
 *              AeroRoutingSlaBreachSubscriberHandler. Gated by Aero_Trigger_Switch__mdt
 *              'AeroRouteSlaBreachSubscriber' (ships off) so customers can disable the
 *              default auto-email behavior and wire their own consumer. The switch check +
 *              delegation live in the handler's static handle(...) so the trigger stays one line.
 */
trigger AeroRoutingSlaBreachSubscriber on Aero_SLA_Breach__e (after insert) {
    AeroRoutingSlaBreachSubscriberHandler.handle(Trigger.new);
}