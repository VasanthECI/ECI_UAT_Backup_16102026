/** Trigger Name: QuoteTriggerDelQLI
* @description       : Enforces business validations on SBQQ__Quote__c and handles quote processing on create,
*                      update, and delete; delegates recurring checks, related content, and delete validation
*                      to QuoteLineItemDeletion, and after-update recalculation / Avalara tax to QuoteTriggerHandler.
*
* @author            : Madhumitha
* @since             : 03/19/2025
*
* Version History:
* Version : 1.0 – Initial trigger for quote line processing and validations via QuoteLineItemDeletion
* Version : 1.2 – SFDEV-1275 (Madhumitha): Quote recalculation when Billing Frequency / Payment Terms change; delegates to QuoteTriggerHandler (10/30/2025)
* Version : 1.3 – (Madhumitha): Family Attribution validation before quote approval, controlled via TriggerSwitchUtility (03/19/2025)
* Version : 1.4 – SFDEV-1845 (Jayanthi): After-update path invokes QuoteTriggerHandler for Avalara tax calculation at quote approval (05/19/2026)
*/
trigger QuoteTriggerDelQLI on SBQQ__Quote__c (after update, after insert,before insert,before delete,before update) {
    if(Trigger.isDelete){
        for(SBQQ__Quote__c q:Trigger.old){
            // if(q.Ghost_Quote__c) q.addError('Ghost Quote cannot be deleted temporarily');
        }
    }
    
    if(Trigger.isInsert || Trigger.isUpdate){
        for(SBQQ__Quote__c quote:Trigger.New){
            if(quote.Ghost_Quote__c) return;
        }
    }
    
    
    if(Trigger.isBefore && Trigger.isInsert){
        
        Map<Id,SBQQ__Quote__c>quoteMap=new Map<Id,SBQQ__Quote__c>();
        for(SBQQ__Quote__c quote:Trigger.New){
            quoteMap.put(quote.SBQQ__Opportunity2__c,quote);
        }  
        Map<Id,Opportunity> oppPro= new Map<Id,Opportunity>([Select id, (Select id From OpportunityLineItems),(SELECT Id FROM SBQQ__Quotes2__r) From Opportunity  Where Id=:quoteMap.keyset()]);
        
        if(!quoteMap.values().isEmpty()){
            for(SBQQ__Quote__c quote : quoteMap.values()){
                if(oppPro.keyset().contains(quote.SBQQ__Opportunity2__c)){
                    List<OpportunityLineItem>oppLine=oppPro.get(quote.SBQQ__Opportunity2__c).OpportunityLineItems;
                    List<SBQQ__Quote__c> oppQuote=oppPro.get(quote.SBQQ__Opportunity2__c).SBQQ__Quotes2__r;
                    if(oppLine.size()!=0 && oppQuote.size()==0 && quote.SBQQ__Type__c != 'Renewal'){
                        quote.addError(label.OpportunityProductsWithoutQuote);
                    }
                }
            }
        }
    }
    
    if(Trigger.isAfter)
    {
        list<SBQQ__Quote__c> quotelist = new list<SBQQ__Quote__c>();
        for(SBQQ__Quote__c q: trigger.new){
            if((trigger.isinsert || q.Subsidiary__c != trigger.oldmap.get(q.id).Subsidiary__c  || q.Opportunity_Type__c != trigger.oldmap.get(q.id).Opportunity_Type__c ||q.SBQQ__ShippingCountry__c != trigger.oldmap.get(q.id).SBQQ__ShippingCountry__c)
              ){
                  quotelist.add(q);
              }
        }
        if(quotelist.size()>0){
            QuoteLineItemDeletion.QuoteDocumentaddition(quotelist,trigger.oldmap,trigger.isinsert);
        }
        
        if(Trigger.isinsert){
            Set<Id> QliIds = new Set<Id>();
            for(SBQQ__Quote__c q: trigger.new){
                if(q.SBQQ__Type__c == 'Renewal'){
                    QliIds.add(q.id);
                    String quoteJSON = SBQQ.ServiceRouter.read('SBQQ.QuoteAPI.QuoteReader', q.id);
                    QuoteModel quoteModel = (QuoteModel) JSON.deserialize(quoteJSON, QuoteModel.class);
                    system.debug('quote API');
                    QuoteCalculator calculator = new QuoteCalculator();
                    //calculator.calculate(quoteModel, 'MyCallback');
                }
            }
            if(QliIds.size()>0){
                //QuoteLineItemDeletion.calculateqli(QliIds);
            }
        }
        
        /*if(Trigger.isUpdate && QuoteLineItemDeletion.recursivecheck3 == false)
{ 

QuoteLineItemDeletion.checkQuantity(Trigger.New);

}*/
        
        if(Trigger.isupdate && QuoteLineItemDeletion.recursivecheck == false){
            QuoteLineItemDeletion.checkrecurring(Trigger.New,trigger.oldmap);
        }
    }
    if(trigger.isbefore&&trigger.isdelete){
        QuoteLineItemDeletion.QuotedelValidation(trigger.old);
        
    }
    // SFDEV:1275 -Call QuoteTriggerHandler for quote recalculation
    if(Trigger.isAfter && Trigger.isUpdate) {
        QuoteTriggerHandler.handleAfterUpdate(Trigger.new, Trigger.oldMap);
    }
    //SFDEV:1275 -End
    //SFDEV-1682 - Trigger switch to validate Family Attribution before quote approval
    if(TriggerSwitchUtility.isTriggerActivated('QuoteApprovalFamilyAttribValidation')){
        if (Trigger.isBefore && Trigger.isUpdate) {
            for (SBQQ__Quote__c q : Trigger.new) {
                SBQQ__Quote__c oldQ = Trigger.oldMap.get(q.Id);
                if (oldQ != null && q.SBQQ__Status__c == 'Approved' && oldQ.SBQQ__Status__c != 'Approved') {
                    String validationError = FamilyAttribController.validateFamilyAttribForApproval(q.Id);
                    System.debug('[FamilyAttrib] validateFamilyAttribForApproval error: ' + validationError);
                    if (validationError != null) {
                        q.addError(validationError);
                    }
                }
            }
        }
    }
}