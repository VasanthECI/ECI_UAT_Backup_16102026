trigger NS_Invoice_Trigger on NS_Invoice__c (after insert, after update) {
    
    if(!TriggerSwitchUtility.isTriggerActivated('NS_Invoice__c')){
        System.debug('NS Invoice Trigger disabled');
       	return;    
    }
    if(trigger.isAfter){
        
        List<NS_Invoice__c> invoiceRecords = new List<NS_Invoice__c>();
        boolean dueDateChanged = false;
        boolean balanceChanged = false;
        for(NS_Invoice__c inv :Trigger.new){
            if(trigger.isInsert){
                dueDateChanged = true;
                balanceChanged = true;
            	invoiceRecords.add(inv);    
            } else if(trigger.isUpdate){
            	NS_Invoice__c oldRec = trigger.oldMap.get(inv.Id);		
                if(inv.Balance__c != oldRec.Balance__c || inv.Date__c != oldRec.Date__c || 
                   inv.Total_with_Tax__c != oldRec.Total_with_Tax__c){
                    balanceChanged = true;
                	invoiceRecords.add(inv);        
                }
                if(inv.Due_Date_Receive_By__c != oldRec.Due_Date_Receive_By__c || inv.Balance__c != oldRec.Balance__c ||
                   inv.Status__c != oldRec.Status__c || inv.Type__c != oldRec.Type__c  || 
                                 inv.Disregard_for_A_R_Hold__c != oldRec.Disregard_for_A_R_Hold__c){
                    dueDateChanged = true;
                	invoiceRecords.add(inv);            
                }
            }
        } 
        
        if(!InvoiceTriggerHandler.isRolledUp && invoiceRecords.size() > 0){
            system.debug('111111'+invoiceRecords);
            system.debug('222222'+dueDateChanged);
            system.debug('333333'+balanceChanged);
        	InvoiceTriggerHandler2.rollUpInvoiceToAccount(invoiceRecords,dueDateChanged,balanceChanged);    
        }
    }
}