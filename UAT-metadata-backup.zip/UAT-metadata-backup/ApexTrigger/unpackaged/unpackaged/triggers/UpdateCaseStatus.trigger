trigger UpdateCaseStatus on FeedComment (before insert,after insert, after update) {
    
    
    if(trigger.isBefore){
        //System.debug('before Trigger');
        // Added as part of Ticket 543 to throw error when Activity added on Closed cases
        if(trigger.isInsert){
            CaseServices.validateCommentsAndFeed(new List<FeedItem>(),trigger.new);        
        }
    }else{
        System.debug('Feed Trigger');
        CaseServices.updateCaseStatusOnComment(trigger.new);    
    }
    
}