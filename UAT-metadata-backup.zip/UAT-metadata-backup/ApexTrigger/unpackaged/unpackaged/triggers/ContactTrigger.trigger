/**
* Class Name: ContactTrigger
* Description:
* 
* Author: 
* Date Created: 
* Last Modified: 2026/06/08
* 
* Version History:
* Version : 1.3
* Author  : Portal Team
* Changes : Invoke ContactPermissionSetHandler.assignPermissionSet on after insert/update
*           when Billing__c is checked to assign subsidiary-specific permission sets via
*           Payment_Gateway_Routing__mdt.
* Date    : 2026/06/08

* Version : 1.2 
* Author  : vasanth
* Changes : The API changed from 'Contact_SV__c' to 'CSV_C'. 
* Date    : 02/06/2025


*/

trigger ContactTrigger on Contact (before insert, after insert, before update, after update, before delete, after delete) {
    system.debug('inside con trigger');
    //As part of 1883 this ContactTriggerHelper.preInactivateUsers() we have been moved to "de-ActivatePortalUser" flow
    //ContactTriggerHelper.preInactivateUsers(Trigger.new,Trigger.oldMap, Trigger.isAfter,Trigger.isBefore,Trigger.isUpdate);
    if(Trigger.isAfter && (Trigger.isInsert || Trigger.isUpdate)){
        //set<id> contactIds = new set<id>();
        if(TriggerSwitchUtility.isTriggerActivated('AccountAddress')){
            if(AccountTriggerHandler.accountaddressboolean == false || Trigger.isInsert)
                ContactTriggerHelper.updateAddress(trigger.new,trigger.oldmap,Trigger.isInsert);
            if(Trigger.isUpdate){
                system.debug('inside con trigger update');
                ContactTriggerHelper.updateOpenQuotes(trigger.new,trigger.oldmap);
            }
        }
        ContactPermissionSetHandler.assignPermissionSet(Trigger.new, Trigger.oldMap);
        //ContactTriggerHelper.primaryContact(trigger.new);
        // This part was commented out because we changed the field name from SkipValidation__c to CSV__c, and also updated the skip validation logic to use ISCHANGED related to SFDEV-537.
        /*for(contact c: trigger.new){
if(c.CSV__c){
contactIds.add(c.id);
}
}
if(contactIds.size()>0 ){
ContactTriggerHelper.updateSkipValidation(contactIds);
}*/
        
    }
    
    if(Trigger.isBefore ){
        if(Trigger.isInsert || Trigger.isUpdate)
            /* Satheesh-SFDEV-22 Start */
            ContactTriggerHelper.BothBillingShippingToFalse(trigger.new,Trigger.oldMap);  // Added OldMap Value in Param for Account Api Id Update *SFDEV - 22*.
        /* Satheesh-SFDEV-22 End */
        if(Trigger.isDelete){
            for(Contact con : trigger.old){
                //Skip_Merge_Validation
                Boolean isSkipValidation = FeatureManagement.checkPermission('Skip_Merge_Validation');
                if(con.Is_Primary__c == true && isSkipValidation == false){
                    con.addError(label.PrimaryContactDelError);
                }
                if(con.Community_Portal__c == true && isSkipValidation == false){
                    con.addError(label.ContactWithCommunityPortalDelError);
                }
            }
        }
    }
    
}