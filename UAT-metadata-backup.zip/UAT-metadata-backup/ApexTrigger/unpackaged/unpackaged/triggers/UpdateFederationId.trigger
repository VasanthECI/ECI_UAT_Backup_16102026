trigger UpdateFederationId on User (before insert,before update) {
    for (User u : Trigger.new) {
                try{
                u.FederationIdentifier = [Select Email from User Where Id = :u.Id].Email;   
                }catch(QueryException ex) {
                
            }
        }
    }