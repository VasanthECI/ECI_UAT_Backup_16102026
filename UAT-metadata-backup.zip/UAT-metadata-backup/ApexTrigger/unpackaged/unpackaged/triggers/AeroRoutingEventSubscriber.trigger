/**
 * @description Platform Event subscriber for Aero_Routing_Event__e. Thin trigger;
 *              all logic lives in AeroRoutingEventSubscriberHandler so it's testable.
 *
 *              Trigger switch: gated by Aero_Trigger_Switch__mdt 'AeroRouteEventSubscriber'
 *              (defaults to active if no metadata row exists). The switch check + delegation
 *              live in the handler's static handle(...) so the trigger stays a single line.
 */
trigger AeroRoutingEventSubscriber on Aero_Routing_Event__e (after insert) {
    AeroRoutingEventSubscriberHandler.handle(Trigger.new);
}