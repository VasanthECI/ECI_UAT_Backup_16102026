/**
 * @description Apex trigger on `Usage_Data__c`. Augments the existing
 *              `force-app/main/default/triggers/UsageDataTrigger.trigger`
 *              (which currently fires only on `before update` for the
 *              Pricing pipeline) by adding `after update` so the Usage
 *              Ingestion project can react to the
 *              `Status__c` → `Pending Billing` transition.
 *
 *              ⚠️ DEPLOY PROCEDURE:
 *              This file is the PROPOSED replacement for the existing
 *              `UsageDataTrigger`. When promoting the project, replace the
 *              active trigger contents with the body below. The
 *              `before update` branch is preserved verbatim (it routes
 *              into the existing `UsageDataTriggerHandler` for the
 *              Pricing transition). The `after update` branch is the
 *              new code, routing into `UsageDataPendingBillingHandler`.
 *
 *              Both branches are independent — the `before update`
 *              branch never reads or writes `Status__c='Pending Billing'`
 *              and the `after update` branch never reads or writes
 *              `Status__c='Pricing'`, so no recursion or interference
 *              is possible.
 *
 *              Per the project standard, triggers contain no business
 *              logic; they only route Trigger context to handler classes.
 *
 * @author Surya — original (`before update` / Pricing branch);
 *         v2.0 contributions and `after update` / Pending Billing
 *         branch by Michael Morrell.
 * @version 2.0
 * @since 2026-04-28
 *
 * Versioning:
 * - 2.0 (2026-05-10) — Stable Release for UAT (first promotion out of
 *   sandbox). Both branches in place: `before update` →
 *   `UsageDataTriggerHandler.onBeforeUpdate` (Pricing); `after update`
 *   → `UsageDataPendingBillingHandler.onAfterUpdate` (Pending Billing
 *   → BS/BSG). Consolidates the v1.x pre-stable increments; see
 *   `POC/ECI_Usage_Ingestion/RELEASE_NOTES_2.0.md` for the full
 *   pre-stable changelog.
 */
trigger UsageDataTrigger on Usage_Data__c (before update, after update) {
    if (Trigger.isBefore && Trigger.isUpdate) {
        new UsageDataTriggerHandler().onBeforeUpdate(Trigger.new, Trigger.oldMap);
    } else if (Trigger.isAfter && Trigger.isUpdate) {
        UsageDataPendingBillingHandler.onAfterUpdate(Trigger.new, Trigger.oldMap);
    }
}