/**
 * @description Trigger for Contract object handling before/after insert and update events.
 *              Manages NPS survey scheduling, primary contract determination, primary product updates,
 *              renewal uplift calculations, license module renewal linking/unlinking, and
 *              subscription synchronization. Delegates to ContractTriggerHandler and related handlers.
 * 
 * @author Aruljothi
 * @since 2025-08-05 v1.4 (SFDEV-837) License Module unlinking during contract renewal
 * 
 * @author Madhumitha
 * @since 2025-11-07 v1.5 (SFDEV-1308) Added handleAfterInsert for Standard Renewal Uplift population
 * 
 * @author Vidhya
 * @since 2026-01-19 v1.6 (SFDEV-1480) Handle License & LM renewal only on contract last date
 * 
 * @group Contract Management
 * @see ContractTriggerHandler
 * @see ContractPrimaryProductHandler
 * @see LicenseModuleManager
 * 
 * Version History:
* Version : 1.1 
* Author  : Aruljothi
* Changes : Comment out ContractTriggerHandler.handleContracts(), Morrell requested to remove the error and related logic (label.Renewal_Uplift_Override_Error) in SFDEV-837
updated where condition (and Cancelled__c=false ) in line no 126
* Date    : 02/06/2025

* Version History:
* Version : 1.2
* Author  : Vidhya
* Changes : SFDEV 967 - Handle Contract Primary Product update logic
* Date    : 20/05/2025

* Version History:
* Version : 1.3
* Author  : Aruljothi
* Changes : Handles Contract-level logic related to Renewal Uplift when the trigger switch is enabled.
handleBeforeUpdate(), handleBeforeInsert() - Before insert/update: setup via ContractTriggerHandler.
handleStandardRenewalUpliftChange() - After update: propagates changes in Standard Renewal Uplift to related Subscriptions.
updateRenewedContractUpliftRate() - This method used to update renewed contract's CPI Uplift/ Override Uplift Rate , Uplift Rate Cap
updateContractCapValue() method used to update related subscription with relevan data for data sync
Ensures consistent uplift logic between Contracts and Subscriptions.
* Date    : 06/12/2025

* Version History:
* Version : 1.4
* Author  : Aruljothi
* Changes : During contract renewal, unlink the association between the License Module and its related License, ensuring the License retains only the License Module for the current year's subscription.

* Date    : 05/08/2025

* Version History:
* Version : 1.5
* Author  : Madhumitha
* Changes : Added handleAfterInsert() to revise the order of execution and ensure the Contract’s Standard Renewal Uplift is populated correctly.

* Date    : 07/11/2025

* Version History:
* Version : 1.6
* Author  : Vidhya
* Changes : SFDEV-1480: Handle renewal of License & LM only when the contract is renewed on its last date
* Date    : 01/19/2026

* Version History:
* Version : 1.7
* Author  : Aruljothi
* Changes : SFDEV-1970: LicenseModuleManager.handleRenewal() proceeds only when the renewed contract
*           has at least one related subscription whose product has Nexus Application populated
*           (SBQQ__Product__r.Nexus_Application__c != null). Existing License Module unlink logic unchanged.
* Date    : 06/08/2026

*/

trigger ContractTrigger on Contract (After insert,After update,Before Insert, Before update) {
    set<Id> contractid=new set<Id>();
    System.debug('Trigger Entered === > ');
    if (Trigger.isBefore && Trigger.isUpdate) {
        //ContractTriggerHandler.handleContracts(Trigger.new, trigger.oldMap);
        ContractTriggerHandler.updateNextNPSSurveyDate(Trigger.New);
    }
    if(Trigger.isBefore && Trigger.isInsert){
        ContractTriggerHandler.updateNextNPSSurveyDate(Trigger.New);        
    }
    if(Trigger.IsAfter && Trigger.isInsert){        
        ContractTriggerHandler.updatePrimaryContract(Trigger.NewMap, Trigger.NewMap);
        // ContractTriggerHandler.updatePrimaryProduct(Trigger.new);
        
        // Refactored code to handle PrimaryProduct update on Contracts in ContractPrimaryProductHandler
        ContractPrimaryProductHandler.updatePrimaryProduct(Trigger.new);
    }

    Set<Id> renewedContractIds = new Set<Id>();

    if(Trigger.IsAfter && Trigger.isUpdate){
        System.debug('Method Entered === > ');
        if(AvoidRecursive.isFirstRun == true){
            AvoidRecursive.isFirstRun=false;
            System.debug('Method Entered After First Run Condition === > ');
            ContractTriggerHandler.updatePrimaryContract(Trigger.NewMap, Trigger.OldMap); 
            //ContractTriggerHandler.updatePrimaryProduct(Trigger.new);
            
            // SFDEV 967 - Refactored code to handle PrimaryProduct update on Contracts in ContractPrimaryProductHandler
            ContractPrimaryProductHandler.updatePrimaryProduct(Trigger.new);
        }

        // To store the Contract IDs that are 'Renewed' on its last date
        Set<Id> lastDayRenewedContractIds = new Set<Id>();
        Map<Id, Id> renewedOldToRenewalNewContractMap = new Map<Id, Id>();

        for (Contract contr : Trigger.new) {
            Contract oldContr = Trigger.oldMap.get(contr.Id);
            if (contr.Renewed_Into__c != oldContr.Renewed_Into__c && !String.isBlank(contr.Renewed_Into__c)) {
                renewedContractIds.add(contr.Id);
                
                // SFDEV-1480 : Unlink the license from existing contract and 
                // link it to the new renewed contract ONLY on the renewed Contract StartDate
                // which will be handled in a new batch
                // Update: If the contract is renewed on its last date, then linking/unlinking of
                // of LM & License will happen immediately
                if(contr.EndDate == Date.today() &&  contr.Renewed_Into__c != null)
                {
                    // If a contract is renewed on its last date, then add the contract id to the map
                    renewedOldToRenewalNewContractMap.put(contr.Id, contr.Renewed_Into__c);
                } 
            }        
        } // for loop ends
        System.debug('renewedOldToRenewalNewContractMap :: ' + renewedOldToRenewalNewContractMap);
        // lastDayRenewedContractIds is used to update the related license for the new renewal contract
        lastDayRenewedContractIds = renewedOldToRenewalNewContractMap.keySet(); 
      
            if(TriggerSwitchUtility.isTriggerActivated('License_Module__c')){
                // SFDEV-1480: Handle renewal of License & LM only when the contract is renewed on its last date
                // SFDEV-1970: handleRenewal proceeds only when a related subscription product has Nexus Application
                if (!renewedOldToRenewalNewContractMap.isEmpty()) 
                   // LicenseModuleManager.handleRenewalLinkAndUnlinkLicense(renewedOldToRenewalNewContractMap);
                   LicenseModuleManager.handleRenewal(lastDayRenewedContractIds);
            }
            
            // SFDEV-1480 : Update the related license for the new renewed contract
            // if contract is renewed on its last date                         
            ContractTriggerHandler.updateRelatedLicense(lastDayRenewedContractIds);
          
            // UpdateRenewedContractUpliftRate - does not involve license and hence called
            if (TriggerSwitchUtility.isTriggerActivated('RenewalUplift')) {
                ContractTriggerHandler.updateRenewedContractUpliftRate(renewedContractIds);
            }
       
        
        
    }
    
    if(Trigger.isBefore && Trigger.isUpdate){
        system.debug('Before update contractid:');
        for(Contract contr:Trigger.new){
            system.debug('Before update contractid:'+contr.id);
            if(contr.SBQQ__RenewalQuoted__c==true){
                contractid.add(contr.id);
            }
        }
        if(contractid.size()>0){
            system.debug('Contracts with RenewalQuote checked:'+contractid);
            ContractTriggerHandler.handleRenewalContracts(contractid,Trigger.new);            
        }
        
    } 
    
    // Execute only if the RenewalUplift trigger switch is activated
    if (TriggerSwitchUtility.isTriggerActivated('RenewalUplift')) {
        
        // BEFORE context: handle contract creation and updates
        if (Trigger.isBefore) {
            
            // Handle logic before inserting new Contracts
            if (Trigger.isInsert) {
                ContractTriggerHandler.handleBeforeInsert(Trigger.new);
            }
            
            // Handle logic before updating existing Contracts
            if (Trigger.isUpdate) {
                ContractTriggerHandler.handleBeforeUpdate(Trigger.new, Trigger.oldMap);
            }
            
        }
        
        //SFDEV 1308
        if(Trigger.IsAfter && Trigger.isInsert)
        {
            ContractTriggerHandler.handleAfterInsert(Trigger.new);
        }       
        
        
        if (Trigger.isAfter && Trigger.isUpdate) {
            Set<Id> ContractIds = new Set<Id>();
            // AFTER UPDATE: propagate Standard Renewal Uplift changes to linked Subscriptions     
            if (!Trigger.new.isEmpty() && Trigger.oldMap != null) {
                ContractTriggerHandler.handleStandardRenewalUpliftChange(
                    Trigger.new,
                    Trigger.oldMap
                );
            }
            //updateContractCapValue() method used to update related subscription with relevan data for data sync
            for (Contract contr : Trigger.new) {
                Contract oldContr = Trigger.oldMap.get(contr.Id);
                if (contr.Uplift_Rate_Cap__c  != oldContr.Uplift_Rate_Cap__c) {
                    ContractIds.add(contr.Id);
                    
                }
            }
            if (!ContractIds.isEmpty()) {
                ContractTriggerHandler.updateContractCapValue(ContractIds);
            }
        }
    }
    
    
    
}