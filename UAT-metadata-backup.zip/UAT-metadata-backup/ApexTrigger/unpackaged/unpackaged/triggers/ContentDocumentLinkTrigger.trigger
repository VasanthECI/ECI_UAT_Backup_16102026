/**
* Trigger Name: ContentDocumentLinkTrigger
* Description: This trigger handles ContentDocumentLink events to manage file-related automation across Salesforce objects.
  It posts Chatter notifications when Community users attach files to Cases, validates that Community users cannot add files to closed Cases,
  and automatically links documents from DocuSign Envelope Status and Box Sign records to their related Opportunity and Quote Document records.
* 
* Author: 
* Date Created: 
* Last Modified: 

* Version History:

* Version : 1.1
* Author  : Vasanth
* Changes : SFDEV - 1200 - Added call to 'createNewBoxsignContentDocumentLink' method to auto-link Box Sign documents to Opportunity and Quote Document records.
* Date    : 10/2/2026
*/

trigger ContentDocumentLinkTrigger on ContentDocumentLink (before insert, after insert, before update, after update, before delete, after delete) {

    //post chatter to case
    ContentDocumentLinkTriggerHelper.caseChatter(Trigger.new, Trigger.isAfter, Trigger.isInsert);
    
    //Restrict community users from ading files to closed case
    ContentDocumentLinkTriggerHelper.validateFiles(Trigger.new, Trigger.isBefore, Trigger.isInsert);
    
    // Create new ContentDocumentLink if LinkedEntityId starts with 'aE8' after insert
    if (Trigger.isAfter && Trigger.isInsert) {
       // ContentDocumentLinkTriggerHelper.createNewContentDocumentLink(Trigger.new);
        ContentDocumentLinkTriggerHelper.createNewBoxsignContentDocumentLink(Trigger.new);
        ContentDocumentLinkTriggerHelper.updateInvoiceCDLVisibility(Trigger.new);
   		ContentDocumentLinkTriggerHelper.deleteOldPurchaseOrderDocuments(Trigger.new);
    }
    
}