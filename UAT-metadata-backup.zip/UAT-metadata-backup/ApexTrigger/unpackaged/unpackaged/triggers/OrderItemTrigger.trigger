/**
 * @description Delegates to {@link OrderItemRevenueAmountHandler} to maintain {@code Revenue_Amount__c} on order products,
 *              and to {@link OrderItemBillingDefaultsService} to stamp the default billing/tax treatments and legal entity.
 * @author       Michael Morrell
 * @date         2026-04-08
 * @version      1.2
 *
 * Version History:
 * - 1.2 (2026-05-31) — Added OrderItemBillingDefaultsService on before insert
 *   (default billing/tax treatments + Account.Subsidiary-resolved legal entity).
 */
trigger OrderItemTrigger on OrderItem (before insert, after insert, after update, after delete) {
    if (Trigger.isBefore && Trigger.isInsert) {
        OrderItemRevenueAmountHandler.handleBeforeInsert(Trigger.new);
        OrderItemBillingDefaultsService.applyDefaults(Trigger.new);
    } else if (Trigger.isAfter && Trigger.isDelete) {
        OrderItemRevenueAmountHandler.handleAfterDelete(Trigger.old);
    } else if (Trigger.isAfter) {
        OrderItemRevenueAmountHandler.handleAfterInsertUpdate(Trigger.new);
    }
}