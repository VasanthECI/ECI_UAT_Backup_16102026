/**
 * @description Plan B / close path: when a LegalEntyAccountingPeriod transitions TO 'Closed',
 * generate paired unrealized FX gain/loss TransactionJournals for the period.
 *
 * Delegates to LegalEntyAccountingPeriodFxCloseHandler → FxUnrealizedCloseQueueable →
 * LegalEntyFxUnrealizedGainLossPoc so the multi-object SOQL + DML run OUTSIDE the
 * status-update transaction -- avoids governor pressure and mixed-DML surprises.
 *
 * STATUS PREDICATE: 'Closed' is assumed LegalEntyAccountingPeriodStatus.CLOSED.getApiValue().
 * Update CLOSED in LegalEntyAccountingPeriodFxCloseHandler if RCB uses a different apiValue.
 *
 * Reopen-side deletion is intentionally NOT used (client: leave Unrealized + UnrealizedReversal
 * in place; reversal is booked at close onto the next period).
 *
 * No PMD suppressions — trigger body is a one-line delegate.
 */
trigger LegalEntyAccountingPeriodFxCloseTrigger on LegalEntyAccountingPeriod (after update) {
    LegalEntyAccountingPeriodFxCloseHandler.afterUpdate(Trigger.new, Trigger.oldMap);
}