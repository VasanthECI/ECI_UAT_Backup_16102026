/**
* Apex Trigger : UpdateCampMemCreatedDate
* Description  : 
*
* Author       : 
* Date Created : 
* Last Modified: 
*
* Version History:
* Version :  1.1
* Author  :  Aruljothi
* Changes :  Updates Contact/Lead fields when Campaign Member.HasResponded = true,
*            replacing the old Status = 'Responded' check.
*			 No updates occur when HasResponded = false.
* Date    :  25-08-2025
*/

trigger UpdateCampMemCreatedDate on CampaignMember (after insert, after update) {
	
	set<Id> ContactIdSet = new set<Id>();
	set<Id> LeadIdSet = new set<Id>();
	
	map<Id,Contact> ContactMap = new map<Id,Contact>();
	map<Id,Lead> LeadMap = new map<Id,Lead>();
	
	for(CampaignMember CMP : trigger.new){
		if(trigger.isInsert){
			if(CMP.HasResponded  == true){
				if(CMP.ContactID != Null){
					ContactIdSet.add(CMP.ContactID);
				}else if(CMP.LeadID != Null){
					LeadIdSet.add(CMP.LeadID);
				}
			}	
		}
		else if(trigger.isupdate){
			if(CMP.HasResponded  == true /*&& trigger.oldmap.get(CMP.Id).Status != CMP.Status*/){
				if(CMP.ContactID != Null){
					ContactIdSet.add(CMP.ContactID);
				}else if(CMP.LeadID != Null){
					LeadIdSet.add(CMP.LeadID);
				}
			}
		}
	}
	if(ContactIdSet != Null && ContactIdSet.size() > 0){
		ContactMap = new map<Id,Contact>([Select Id, Name, Campaign_Member_Created_Date__c, Most_Recent_Response_Campaign_Name__c, Most_Recent_Response_Currency__c, Most_Recent_Response_Product__c from Contact Where Id IN: ContactIdSet]);
	}
	if(LeadIdSet != Null && LeadIdSet.size() > 0){
		LeadMap = new map<Id,Lead>([Select Id, Name, Campaign_Member_Created_Date__c, Most_Recent_Response_Campaign_Name__c, Most_Recent_Response_Currency__c, Most_Recent_Response_Product__c from Lead Where Id IN: LeadIdSet]);
	}
	
	for(CampaignMember CMP : trigger.new){
		if(trigger.isInsert){
			if(ContactMap != Null && ContactMap.size() > 0){
				if(CMP.HasResponded  == true){
					if(CMP.ContactID != Null && CMP.Response_Tracking_Date__c != Null){
						if(ContactMap.get(CMP.ContactID) != Null){
							ContactMap.get(CMP.ContactID).Campaign_Member_Created_Date__c = CMP.Response_Tracking_Date__c;
							ContactMap.get(CMP.ContactID).Most_Recent_Response_Campaign_Name__c = CMP.Campaign_Name__c;
							ContactMap.get(CMP.ContactID).Most_Recent_Response_Currency__c = CMP.Currency__c;
							ContactMap.get(CMP.ContactID).Most_Recent_Response_Product__c = CMP.ECi_Product__c;
						}
					}
				}
			}
			if(LeadMap != Null && LeadMap.size() > 0){
				system.debug('The Camp mem status is'+CMP.Status);
				system.debug('The Camp mem status is'+CMP.Response_Tracking_Date__c);
				system.debug('The Camp mem status is'+CMP.LeadID);
				if(CMP.HasResponded  == true){
					if(CMP.LeadId != Null && CMP.Response_Tracking_Date__c != Null){
						if(LeadMap.get(CMP.LeadId) != Null){
							LeadMap.get(CMP.LeadId).Campaign_Member_Created_Date__c = CMP.Response_Tracking_Date__c;
							LeadMap.get(CMP.LeadId).Most_Recent_Response_Campaign_Name__c = CMP.Campaign_Name__c;
							LeadMap.get(CMP.LeadId).Most_Recent_Response_Currency__c = CMP.Currency__c;
							LeadMap.get(CMP.LeadId).Most_Recent_Response_Product__c = CMP.ECi_Product__c;
						}
					}
				}	
			}
		}else if(trigger.isupdate){
			if(ContactMap != Null && ContactMap.size() > 0){
				if(CMP.HasResponded  == true /* && trigger.oldmap.get(CMP.Id).Status != CMP.Status*/){
					if(CMP.ContactID != Null && CMP.Response_Tracking_Date__c != Null){
						if(ContactMap.get(CMP.ContactID) != Null){
							ContactMap.get(CMP.ContactID).Campaign_Member_Created_Date__c = CMP.Response_Tracking_Date__c;
							ContactMap.get(CMP.ContactID).Most_Recent_Response_Campaign_Name__c = CMP.Campaign_Name__c;
							ContactMap.get(CMP.ContactID).Most_Recent_Response_Currency__c = CMP.Currency__c;
							ContactMap.get(CMP.ContactID).Most_Recent_Response_Product__c = CMP.ECi_Product__c;
						}
					}
				}
			}
			if(LeadMap != Null && LeadMap.size() > 0){
				if(CMP.HasResponded  == true /* && trigger.oldmap.get(CMP.Id).Status != CMP.Status*/){
					if(CMP.LeadId != Null && CMP.Response_Tracking_Date__c != Null){
						if(LeadMap.get(CMP.LeadId) != Null){
							LeadMap.get(CMP.LeadId).Campaign_Member_Created_Date__c = CMP.Response_Tracking_Date__c;
							LeadMap.get(CMP.LeadId).Most_Recent_Response_Campaign_Name__c = CMP.Campaign_Name__c;
							LeadMap.get(CMP.LeadId).Most_Recent_Response_Currency__c = CMP.Currency__c;
							LeadMap.get(CMP.LeadId).Most_Recent_Response_Product__c = CMP.ECi_Product__c;
						}
					}
				}	
			}
		}
	}
	if(ContactMap != Null && ContactMap.size() > 0){
		update ContactMap.values();
	}
	if(LeadMap != Null && LeadMap.size() > 0){
		update LeadMap.values();
	}
}