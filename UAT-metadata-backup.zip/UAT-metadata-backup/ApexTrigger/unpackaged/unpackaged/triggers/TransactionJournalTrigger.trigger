/**
 * @description Trigger on Transaction Journal.
 *              Before insert: stamps functional currency ISO/amounts when source data exists.
 *              After insert: enqueues delayed Queueable for Payment/Refund when functional
 *              fields were not yet populated (e.g. Customer Portal), and for Salesforce
 *              Sale payments whose general ledger accounts were assigned to the default
 *              legal entity.
 *
 *              Contains no business logic - delegates to TransactionJournalTriggerHandler.
 *
 * @author Cursor Agent
 * @since 2026-08-12
 * @see TransactionJournalTriggerHandler
 * @see TJFunctionalCurrencyService 
 */
trigger TransactionJournalTrigger on TransactionJournal (before insert, after insert) {
    TransactionJournalTriggerHandler.handleInsert(Trigger.new, Trigger.isBefore);
}