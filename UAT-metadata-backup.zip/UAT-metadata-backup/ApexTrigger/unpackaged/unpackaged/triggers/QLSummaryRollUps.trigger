/**
 * Trigger Name: QLSummaryRollUps
 * Description:
 * 
 * Author: 
 * Date Created: 
 * Last Modified: 
 * 
 * Version History:
 * Version : 1.2 
 * Author  : Comment the line 174 Calculator.calculate(quoteModel, 'MyCallback'); for to avoid the Too many queueable jobs
 *           in run the batch class BatchforContractStatusUpdate
 * Date    : 27/02/2025
*/
trigger QLSummaryRollUps on SBQQ__QuoteLine__c (after insert, after update) {
    if(!TriggerSwitchCache.isTriggerActive('QuoteLine')){
        System.debug('QuoteLine Trigger disabled');
        return;    
    }
    
    list<id> qlstoDelete = new list<id>();
    list<id> psqlstoDelete = new list<id>();
    list<SBQQ__QuoteLine__c> qlstoDel = new list<SBQQ__QuoteLine__c>();
    list<SBQQ__QuoteLine__c> qlstoInsert = new list<SBQQ__QuoteLine__c>();
    list<SBQQ__QuoteLine__c> qlstoUpdate = new list<SBQQ__QuoteLine__c>();
    if(trigger.isinsert){
        map<id,SBQQ__QuoteLine__c> qllinsmap = new map<id,SBQQ__QuoteLine__c>([Select id,SBQQ__RequiredBy__r.SBQQ__RequiredBy__r.SBQQ__Product__c,SBQQ__ProductOption__c,SBQQ__ProductOption__r.Exclude_from_Bundle__c,SBQQ__RequiredBy__c,SBQQ__RequiredBy__r.SBQQ__RequiredBy__c from SBQQ__QuoteLine__c where id in: trigger.new ]);
        map<id,id> qlparentidmap = new map<id,id>();
        map<id,id> qloptionidmap = new map<id,id>();
        map<id,list<SBQQ__ProductOption__c>> optionidmap = new map<id,list<SBQQ__ProductOption__c>>();
        for(SBQQ__QuoteLine__c ql:  trigger.new){
            system.debug('qllinsmap.get(ql.id)'+qllinsmap.get(ql.id));
            system.debug('qllinsmap.get(ql.id).SBQQ__ProductOption__r.Exclude_from_Bundle__c'+qllinsmap.get(ql.id).SBQQ__ProductOption__r.Exclude_from_Bundle__c);
            if(qllinsmap.get(ql.id).SBQQ__ProductOption__r.Exclude_from_Bundle__c == true){
                qlparentidmap.put(ql.SBQQ__Product__c,qllinsmap.get(ql.id).SBQQ__RequiredBy__r.SBQQ__RequiredBy__r.SBQQ__Product__c); 
            }
        }
        system.debug('1111'+qlparentidmap);
        list<SBQQ__ProductOption__c> prodopts = [Select id,SBQQ__OptionalSKU__c,SBQQ__ConfiguredSKU__c from SBQQ__ProductOption__c where SBQQ__ConfiguredSKU__c in: qlparentidmap.values()];
        system.debug('2222'+prodopts);
        for(SBQQ__ProductOption__c i : prodopts){
            if(optionidmap.containsKey(i.SBQQ__ConfiguredSKU__c)){
                optionidmap.get(i.SBQQ__ConfiguredSKU__c).add(i);
            }else{
                optionidmap.put(i.SBQQ__ConfiguredSKU__c,new list<SBQQ__ProductOption__c>{i});
            }
        }
        system.debug('optionidmap:'+optionidmap);
        for(id i:qlparentidmap.keyset() ){
            if(optionidmap.get(qlparentidmap.get(i)) != null){
                for(SBQQ__ProductOption__c po: optionidmap.get(qlparentidmap.get(i))){
                    system.debug('po:'+po);
                    if( i == po.SBQQ__OptionalSKU__c){
                        qloptionidmap.put(i,po.id);
                    }
                }
            }
        }
        system.debug('qloptionidmap:'+qloptionidmap);
        for(SBQQ__QuoteLine__c ql:  trigger.new){
            if(qllinsmap.get(ql.id).SBQQ__ProductOption__r.Exclude_from_Bundle__c == true){
                qlstoDelete.add(ql.id);
                SBQQ__QuoteLine__c qlnew = new SBQQ__QuoteLine__c();
                SBQQ__QuoteLine__c qlnew2 = new SBQQ__QuoteLine__c();
                qlnew2.id = ql.SBQQ__RequiredBy__c;
                qlnew2.Need_Recalculation__c = true;
                
                //qlnew = ql.clone(false, false, false, false);
                qlnew.id = ql.id;
                qlnew.SBQQ__ProductOption__c = qloptionidmap.get(ql.SBQQ__Product__c) ;
                qlnew.Exclude_from_Bundle__c = false;
                qlnew.SBQQ__RequiredBy__c = qllinsmap.get(ql.id).SBQQ__RequiredBy__r.SBQQ__RequiredBy__c;
                qlstoInsert.add(qlnew);
                qlstoUpdate.add(qlnew2);
            }
            if(label.PSProducts.contains(ql.SBQQ__Product__c)){
                //== '01t2D000006AcPu'){
                psqlstoDelete.add(ql.id);
            }
        }
        if(qlstoInsert.size()>0)
            update qlstoInsert;
        if(qlstoUpdate.size()>0)
            update qlstoUpdate;
        delete [select id from SBQQ__QuoteLine__c where id in :psqlstoDelete];
        
    }
    system.debug('qlstoDelete:'+qlstoDelete);
    
    if(trigger.isInsert /*|| trigger.isUpdate */){
        //2103
        
        set<Id> accIds = new set<Id>();
        set<Id> qlIds = new set<Id>();
        map<Id, SBQQ__QuoteLine__c> qliMap = new map<Id, SBQQ__QuoteLine__c>();
        for(SBQQ__QuoteLine__c qline: trigger.new){
            if(qline.SBQQ__UpgradedSubscription__c == null && qline.SBQQ__RenewedSubscription__c == null)
                qlIds.add(qline.Id);
        }
        if(!qlIds.isEmpty() && qlIds.size()>0){
            
            list<SBQQ__QuoteLine__c> queriedLines = [select SBQQ__Product__r.Recurring_Status__c, SBQQ__Quote__r.SBQQ__Account__c,
                                                     SBQQ__Quote__r.SBQQ__Opportunity2__r.SBQQ__AmendedContract__c,
                                                     SBQQ__Quote__r.SBQQ__Opportunity2__r.SBQQ__RenewedContract__c,
                                                     SBQQ__Quote__r.SBQQ__Opportunity2__r.Migration_Opportunity__c,
                                                     SBQQ__Quote__r.SBQQ__Opportunity2__r.REC_Allow__c, SBQQ__Quote__c, id 
                                                     from SBQQ__QuoteLine__c where Id IN : qlIds];
            for(SBQQ__QuoteLine__c ql: queriedLines){
                system.debug('quoteLine Rec Status :: '+ql.SBQQ__Product__r.Recurring_Status__c);
                if(ql.SBQQ__Product__r.Recurring_Status__c == true){
                    accIds.add(ql.SBQQ__Quote__r.SBQQ__Account__c);
                    qliMap.put(ql.Id, ql);
                    system.debug('rec QuoteLine ::: '+ql);
                }
            }
            
            system.debug('accIds ::: '+accIds);
            
            list<Contract> activeContracts = [select Status, AccountId, id from Contract where (Status = 'Active' OR Status = 'Draft') and AccountId IN: accIds];
            system.debug('activeContracts ::: '+activeContracts);
            if( !activeContracts.isEmpty() && activeContracts.size() > 0 && !qliMap.isEmpty()){
                map<Id, list<Contract>> accContractsMap = new map<Id, list<Contract>>();
                for(Contract contr : activeContracts){
                    if(accContractsMap.containsKey(contr.AccountId)){
                        accContractsMap.get(contr.AccountId).add(contr);
                    }else{
                        accContractsMap.put(contr.AccountId, new list<Contract>{contr});
                    }
                }
                system.debug('accContractsMap ::: '+accContractsMap);
                for(SBQQ__QuoteLine__c li : trigger.new){
                    SBQQ__QuoteLine__c qli = qliMap.get(li.Id);
                    system.debug('iterating quote line ::: '+qli);
                    // system.debug('iterating quote line opty ::: '+qli.SBQQ__Quote__r.SBQQ__Opportunity2__c);
                    // system.debug('iterating quote line acc ::: '+qli.SBQQ__Quote__r.SBQQ__Account__c);
                    if( qli != null && qli.SBQQ__Quote__r.SBQQ__Opportunity2__r.REC_Allow__c == false 
                       && qli.SBQQ__Quote__r.SBQQ__Opportunity2__r.Migration_Opportunity__c == null
                       && qli.SBQQ__Quote__r.SBQQ__Opportunity2__r.SBQQ__AmendedContract__c == null
                       && qli.SBQQ__Quote__r.SBQQ__Opportunity2__r.SBQQ__RenewedContract__c == null
                       && accContractsMap.containsKey(qli.SBQQ__Quote__r.SBQQ__Account__c) ){
                           system.debug('validation fires - as current account has active contract');
                           //li.addError('Current contract should be amended to add REC products');
                           li.addError(label.REC_Products_Addition_Validation);
                       }
                }
            }
        }
    }
    
    if(trigger.isAfter && trigger.isInsert){
        //2138
        set<Id> qlIds = new set<Id>();        
        for(SBQQ__QuoteLine__c qline: trigger.new){
            system.debug('QLSummaryRollUps 2138 ql : '+qline);
            if(qline.SBQQ__RenewedSubscription__c != null /*&& !qline.SBQQ__Quote__r.Ghost_Quote__c*/){
                qlIds.add(qline.Id);
            }
        }
        system.debug('QLSummaryRollUps 2138 qlIds : '+qlIds);
       if(!qlIds.isEmpty() && qlIds != null && !System.IsBatch() && !System.isFuture())
             QuoteLineTriggerHandler.deleteRenewalExclusionLines(qlIds);
        //2207
        set<Id> quoteIds = new set<Id>();
        set<Id> BundlequoteIds = new set<Id>();
        for(SBQQ__QuoteLine__c ql: trigger.new){
            quoteIds.add(ql.SBQQ__Quote__c );
            if(ql.IsBundle__c){
                BundlequoteIds.add(ql.SBQQ__Quote__c );
            }
        }
        System.debug('Debug BundlequoteIds' + BundlequoteIds);
        If(BundlequoteIds.size() > 0){
            for(Id i: BundlequoteIds){
                System.debug( 'BundlequoteIds  ===== > ' + i);
                String quoteJSON = SBQQ.ServiceRouter.read('SBQQ.QuoteAPI.QuoteReader', i);
                QuoteModel quoteModel = (QuoteModel) JSON.deserialize(quoteJSON, QuoteModel.class);
                system.debug('quoteJSON'+quoteJSON);
                system.debug('quoteModel'+quoteModel);
                QuoteCalculator calculator = new QuoteCalculator();
                //Calculator.calculate(quoteModel, 'MyCallback'); 
            } 
        }
        
        if(!quoteIds.isEmpty() && !System.IsBatch() && !System.isFuture()) QuoteLineTriggerHandler.onAfterInsert(quoteIds);
    }
    
    Set<Id> relatedQuoteIds = new Set<Id>();
    
    for (SBQQ__QuoteLine__c quoteLine : Trigger.new) {
        system.debug(quoteLine.Initial_Payment__c + 'quoteLine.Initial_Payment__c');
        if (Trigger.isInsert || (Trigger.isUpdate &&(quoteLine.Initial_Payment__c != Trigger.oldMap.get(quoteLine.Id).Initial_Payment__c || quoteLine.SBQQ__ProrateMultiplier__c != Trigger.oldMap.get(quoteLine.Id).SBQQ__ProrateMultiplier__c ||quoteLine.SBQQ__Quote__r.SBQQ__SubscriptionTerm__c != Trigger.oldMap.get(quoteLine.Id).SBQQ__Quote__r.SBQQ__SubscriptionTerm__c || quoteLine.SBQQ__CustomerTotal__c != Trigger.oldMap.get(quoteLine.Id).SBQQ__CustomerTotal__c  ))) {
            system.debug(quoteLine.Initial_Payment__c + 'quoteLine.Initial_Payment__c inside if');
            if (quoteLine.SBQQ__Quote__c != null) {
                relatedQuoteIds.add(quoteLine.SBQQ__Quote__c);
            }
        }
    }
    
    if (TriggerSwitchCache.isTriggerActive('AbatementCreditsCalculation')) {
        system.debug('Field Abatement Credits logic started..');
        if (relatedQuoteIds.isEmpty()) return;
        List<SBQQ__QuoteLine__c> relatedQuoteLines = [
            SELECT Id, SBQQ__Quote__c, SBQQ__CustomerTotal__c, SBQQ__SegmentIndex__c,SBQQ__SegmentKey__c,
            SBQQ__ProrateMultiplier__c,Initial_Payment__c,SBQQ__Product__r.SBQQ__BillingFrequency__c, Abatement_Credit__c
            FROM SBQQ__QuoteLine__c
            WHERE SBQQ__Quote__c IN :relatedQuoteIds and SBQQ__SegmentIndex__c=1
        ];
        
        if(!relatedQuoteLines.isEmpty()){
            QuoteLineTriggerHandler.calculateAbatementCredit(relatedQuoteLines);
        }
        system.debug('Abatement Credits logic executed!');
    }else{
        system.debug('Abatement Credits logic failed!');
    }
    
    Public static void ProcessQuoteCalculate(){
        
    }
    
}