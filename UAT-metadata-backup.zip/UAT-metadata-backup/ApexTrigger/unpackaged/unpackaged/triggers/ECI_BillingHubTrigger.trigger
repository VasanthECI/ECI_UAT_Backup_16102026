/**
 * @description Routes ECI Billing Hub after-update events to the trigger handler.
 * @author Michael Morrell
 * @version 1.0
 * @since 2026-05-20
 */
trigger ECI_BillingHubTrigger on ECI_Billing_Hub__c (after update) {
    ECI_BillingHub_TriggerHandler.run();
}