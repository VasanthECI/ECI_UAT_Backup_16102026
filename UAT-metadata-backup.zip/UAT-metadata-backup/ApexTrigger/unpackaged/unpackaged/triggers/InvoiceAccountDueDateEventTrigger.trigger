/**
 * @description Platform Event trigger: Invoice Balance Doc Gen → Account invoice due date.
 *              High Volume PE subscriber, separate from silent PDF regeneration.
 *
 * @see InvoiceAccountDueDateEventTriggerHandler
 */
trigger InvoiceAccountDueDateEventTrigger on Invoice_Balance_Doc_Gen__e (after insert) {
    InvoiceAccountDueDateEventTriggerHandler.process(Trigger.new);
}