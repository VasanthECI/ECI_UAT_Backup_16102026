/**
* Class Name: AccountTrigger
* Description:
* 
* Author: 
* Date Created: 
* Last Modified: 2026/06/08
* 
* Version History:
*
* Version : 1.7
* Author  : Naveen
* Changes : After insert, call AccountDefaultBillingAccountService to create a
*           default Billing Account (skip automatic payments) when none exists.
* Date    : 2026/09/02
*
* Version : 1.6
* Author  : Portal Team
* Changes : On after update when Subsidiary__c changes, call
*           ContactPermissionSetHandler.assignPermissionSetByAccount to reassign permission
*           sets for billing contacts on affected accounts.
* Date    : 2026/06/08
*
* Version : 1.5
* Author  : Naveen S
* Changes : Added Queueable (AccountSharingQueueable) execution on Account after insert/update 
*           to handle sharing when Parent_Support_View__c changes
* Date    : 04/30/2026
*
* Version History:
* Version : 1.4
* Author  : Surya
* Changes : SFDEV-1460 - Commented out line number 314 as a part of removing the qualtrics
* Date    : 07/16/2025

* Version : 1.3
* Author  : Vidhya
* Changes : SFDEV-1120 - To access metadata - Account_Employee_Cohort__mdt & Account_USD_Revenue_Cohort__mdt via Apex instead of Flows
* Date    : 07/16/2025

* Version : 1.2 
* Author  : vasanth
* Changes : The API changed from 'Contact_SV__c' to 'CSV_C'. 
* Date    : 02/06/2025
*/

trigger AccountTrigger on Account
(before insert, before update, after insert, after update, after delete,before delete) {
    if(!TriggerSwitchUtility.isTriggerActivated('Account')){
        System.debug('AccountTrigger Trigger disabled');
        return;    
    }
    if(Trigger.isBefore && Trigger.isDelete){
        system.debug('BeforeDelete');
        set<id> licenseids=new set<id>();
        list<contact> conlstdel = [Select id,CSV__c from contact where accountid in: trigger.old and Is_Primary__c = true];
        List<License__c> AccountLicenses=[select id,License_Status__c,License_Support_Status__c, Name,Account__c from License__c where Account__c in:trigger.old];
        system.debug('BeforeDeletecontc'+conlstdel);
        for(contact c : conlstdel){
            c.Is_Primary__c = false;
            c.CSV__c = c.CSV__c?false:true;
        }
        update conlstdel;
        if(!AccountLicenses.isEmpty()){
            for(License__c lic:AccountLicenses){
                licenseids.add(lic.id);
            }
            system.debug('before passing licenseids to class:'+licenseids);
            AccountTriggerHandler.updatemergedAccountLicense(licenseids);
        }
        
        String ErrorMsg = label.AccountDeletion_ErrorMsg;
        Boolean isSkipValidation = FeatureManagement.checkPermission('Skip_Merge_Validation');
        for(Account acc:trigger.old){
            if((acc.NetSuite_Id__c != null || acc.VAT_Number__c != null || acc.Chamber_of_Commerce_Number__c !=null) && isSkipValidation == false){
                acc.adderror(ErrorMsg);
            }
        }
        
    }else{
        // SFDEV-1120 - Handle metadata in Apex - Before Insert
        if(Trigger.isBefore && Trigger.isInsert){
            for(Account acc : trigger.new)
            {                               
                // SFDEV-1120 - Handle metadata in Apex
                // Employee Cohort Metadata & USD Revenue Cohort metadata
                acc.ZI_Employee_Cohort__c = AccountTriggerHandler.getEmployeeCohortLabelForAcc(acc.NumberOfEmployees);                    
                acc.ZI_USD_Revenue_Cohort__c = AccountTriggerHandler.getRevenueLabelForAcc(acc.Annual_Revenue_in_USD__c);
            } 
        }
        
        if(Trigger.isBefore && Trigger.isUpdate){
            Map<id,Account> accMap= new Map<id,Account>();
            for(Account a : trigger.new){
                if(a.Subsidiary__c!=trigger.oldmap.get(a.id).Subsidiary__c){
                    accMap.put(a.Id,a); 
                }
                // SFDEV-1120 - Handle metadata in Apex - Before Update             
                // Employee Cohort Metadata
                if(a.NumberOfEmployees != trigger.oldmap.get(a.id).NumberOfEmployees)
                    a.ZI_Employee_Cohort__c = AccountTriggerHandler.getEmployeeCohortLabelForAcc(a.NumberOfEmployees);
                
                // USD Revenue Cohort metadata
                if(a.Annual_Revenue_in_USD__c != trigger.oldmap.get(a.id).Annual_Revenue_in_USD__c)
                    a.ZI_USD_Revenue_Cohort__c = AccountTriggerHandler.getRevenueLabelForAcc(a.Annual_Revenue_in_USD__c);
                
            }
            if(accMap.size() > 0)
                AccountTriggerHandler.showSubsidaryValidation(accMap);
        }
        if(Trigger.isBefore && TriggerSwitchUtility.isTriggerActivated('AccountAddress')){
            set<id> contactid = new set<id>();
            if(!AccountTriggerHandler.accountaddressboolean || Test.isRunningTest()){
                for(account act : trigger.new){
                    contactid.add(act.Billing_Contact__c);
                    contactid.add(act.shipping_contact__c);
                }
                map<id,contact> contactMap = new map<id,contact>();
                for(contact con : [select id,MailingStreet,MailingState,Mailingpostalcode,Mailingcity,mailingcountry,Full_Name__c,NSID_Shippingaddress__c,Phone,Email,NSID_Billingaddress__c from contact where id in:contactid ]){
                    contactMap.put(con.id,con);
                }
                for(Account acc : Trigger.new){
                    system.debug('5555'+AccountTriggerHandler.accountaddressboolean);
                    
                    //during insert
                    if(trigger.isinsert ){
                    }
                    // update billing and shipping address if both the contacts are changed to same
                    else if( acc.billing_contact__c == acc.shipping_contact__c && acc.shipping_contact__c != trigger.oldmap.get(acc.Id).shipping_contact__c && acc.Billing_Contact__c != trigger.oldmap.get(acc.Id).Billing_Contact__c){
                        if(acc.shipping_contact__c != null){
                            acc.ShippingStreet = contactMap.get(acc.shipping_contact__c).MailingStreet;
                            acc.ShippingState = contactMap.get(acc.shipping_contact__c).MailingState;
                            acc.Shippingpostalcode = contactMap.get(acc.shipping_contact__c).Mailingpostalcode;
                            acc.ShippingCity = contactMap.get(acc.shipping_contact__c).Mailingcity;
                            acc.ShippingCountry = contactMap.get(acc.shipping_contact__c).mailingcountry;
                            acc.Shipping_Contact_Name__c=contactMap.get(acc.shipping_contact__c).Full_Name__c;
                            acc.Shipping_Contact_Phone__c=contactMap.get(acc.shipping_contact__c).Phone;
                            acc.NSID_Shippingaddress__c=contactMap.get(acc.shipping_contact__c).NSID_Shippingaddress__c;
                        }
                        if(acc.Billing_Contact__c != null){
                            acc.BillingStreet = contactMap.get(acc.Billing_Contact__c).MailingStreet;
                            acc.BillingState = contactMap.get(acc.Billing_Contact__c).MailingState;
                            acc.Billingpostalcode = contactMap.get(acc.Billing_Contact__c).Mailingpostalcode;
                            acc.BillingCity = contactMap.get(acc.Billing_Contact__c).Mailingcity;
                            acc.BillingCountry = contactMap.get(acc.Billing_Contact__c).mailingcountry;
                            acc.Billing_Contact_Email__c = contactMap.get(acc.Billing_Contact__c).Email;
                            acc.Billing_Contact_Name__c = contactMap.get(acc.Billing_Contact__c).Full_Name__c;
                            acc.Billing_Contact_Phone__c = contactMap.get(acc.Billing_Contact__c).Phone;
                            acc.NSID_Billingaddress__c = contactMap.get(acc.Billing_Contact__c).NSID_Billingaddress__c;
                        }
                    }
                    
                    // update billing and shipping address if both the contacts are changed to different
                    else if(acc.billing_contact__c != acc.shipping_contact__c && acc.Billing_Contact__c != trigger.oldmap.get(acc.Id).Billing_Contact__c && acc.shipping_contact__c != trigger.oldmap.get(acc.Id).shipping_contact__c){
                        if(acc.Billing_Contact__c != null){
                            acc.BillingStreet = contactMap.get(acc.billing_contact__c).MailingStreet;
                            acc.BillingState = contactMap.get(acc.billing_contact__c).MailingState;
                            acc.Billingpostalcode = contactMap.get(acc.billing_contact__c).Mailingpostalcode;
                            acc.BillingCity = contactMap.get(acc.billing_contact__c).Mailingcity;
                            acc.BillingCountry = contactMap.get(acc.billing_contact__c).mailingcountry;
                            acc.Billing_Contact_Email__c = contactMap.get(acc.Billing_Contact__c).Email;
                            acc.Billing_Contact_Name__c = contactMap.get(acc.Billing_Contact__c).Full_Name__c;
                            acc.Billing_Contact_Phone__c = contactMap.get(acc.Billing_Contact__c).Phone;
                            acc.NSID_Billingaddress__c = contactMap.get(acc.Billing_Contact__c).NSID_Billingaddress__c;
                        }
                        if(acc.shipping_contact__c != null){
                            acc.ShippingStreet = contactMap.get(acc.shipping_contact__c).MailingStreet;
                            acc.ShippingState = contactMap.get(acc.shipping_contact__c).MailingState;
                            acc.Shippingpostalcode = contactMap.get(acc.shipping_contact__c).Mailingpostalcode;
                            acc.ShippingCity = contactMap.get(acc.shipping_contact__c).Mailingcity;
                            acc.ShippingCountry = contactMap.get(acc.shipping_contact__c).mailingcountry;
                            acc.Shipping_Contact_Name__c=contactMap.get(acc.shipping_contact__c).Full_Name__c;
                            acc.Shipping_Contact_Phone__c=contactMap.get(acc.shipping_contact__c).Phone;
                            acc.NSID_Shippingaddress__c=contactMap.get(acc.shipping_contact__c).NSID_Shippingaddress__c;
                        }
                    }
                    //update address if billing contact is changed similar to shipping contact
                    else if(acc.billing_contact__c == acc.shipping_contact__c && acc.Billing_Contact__c != trigger.oldmap.get(acc.Id).Billing_Contact__c && acc.Billing_Contact__c != null){
                        acc.ShippingStreet = contactMap.get(acc.Billing_Contact__c).MailingStreet;
                        acc.ShippingState = contactMap.get(acc.Billing_Contact__c).MailingState;
                        acc.Shippingpostalcode = contactMap.get(acc.Billing_Contact__c).Mailingpostalcode;
                        acc.ShippingCity = contactMap.get(acc.Billing_Contact__c).Mailingcity;
                        acc.ShippingCountry = contactMap.get(acc.Billing_Contact__c).mailingcountry;
                        acc.Shipping_Contact_Name__c=contactMap.get(acc.Billing_Contact__c).Full_Name__c;
                        acc.Shipping_Contact_Phone__c=contactMap.get(acc.Billing_Contact__c).Phone;
                        acc.NSID_Shippingaddress__c=contactMap.get(acc.Billing_Contact__c).NSID_Shippingaddress__c;
                        
                        acc.BillingStreet = contactMap.get(acc.Billing_Contact__c).MailingStreet;
                        acc.BillingState = contactMap.get(acc.Billing_Contact__c).MailingState;
                        acc.Billingpostalcode = contactMap.get(acc.Billing_Contact__c).Mailingpostalcode;
                        acc.BillingCity = contactMap.get(acc.Billing_Contact__c).Mailingcity;
                        acc.BillingCountry = contactMap.get(acc.Billing_Contact__c).mailingcountry;
                        acc.Billing_Contact_Email__c = contactMap.get(acc.Billing_Contact__c).Email;
                        acc.Billing_Contact_Name__c = contactMap.get(acc.Billing_Contact__c).Full_Name__c;
                        acc.Billing_Contact_Phone__c = contactMap.get(acc.Billing_Contact__c).Phone;
                        acc.NSID_Billingaddress__c = contactMap.get(acc.Billing_Contact__c).NSID_Billingaddress__c;
                    }
                    //update address if shipping contact is changed similar to billing contact
                    else if(acc.billing_contact__c == acc.shipping_contact__c && acc.Shipping_Contact__c != trigger.oldmap.get(acc.Id).Shipping_Contact__c && acc.Shipping_Contact__c != null){
                        acc.BillingStreet = contactMap.get(acc.Shipping_Contact__c).MailingStreet;
                        acc.BillingState = contactMap.get(acc.Shipping_Contact__c).MailingState;
                        acc.Billingpostalcode = contactMap.get(acc.Shipping_Contact__c).Mailingpostalcode;
                        acc.BillingCity = contactMap.get(acc.Shipping_Contact__c).Mailingcity;
                        acc.BillingCountry = contactMap.get(acc.Shipping_Contact__c).mailingcountry;
                        acc.Billing_Contact_Email__c = contactMap.get(acc.Shipping_Contact__c).Email;
                        acc.Billing_Contact_Name__c = contactMap.get(acc.Shipping_Contact__c).Full_Name__c;
                        acc.Billing_Contact_Phone__c = contactMap.get(acc.Shipping_Contact__c).Phone;
                        acc.NSID_Billingaddress__c = contactMap.get(acc.Shipping_Contact__c).NSID_Billingaddress__c;
                        
                        acc.ShippingStreet = contactMap.get(acc.Shipping_Contact__c).MailingStreet;
                        acc.ShippingState = contactMap.get(acc.Shipping_Contact__c).MailingState;
                        acc.Shippingpostalcode = contactMap.get(acc.Shipping_Contact__c).Mailingpostalcode;
                        acc.ShippingCity = contactMap.get(acc.Shipping_Contact__c).Mailingcity;
                        acc.ShippingCountry = contactMap.get(acc.Shipping_Contact__c).mailingcountry;
                        acc.Shipping_Contact_Name__c=contactMap.get(acc.Shipping_Contact__c).Full_Name__c;
                        acc.Shipping_Contact_Phone__c=contactMap.get(acc.Shipping_Contact__c).Phone;
                        acc.NSID_Shippingaddress__c=contactMap.get(acc.Shipping_Contact__c).NSID_Shippingaddress__c;
                    }
                    //if billing contact is updated and not same as shipping contact
                    else if(acc.billing_contact__c != acc.shipping_contact__c && acc.Billing_Contact__c != trigger.oldmap.get(acc.Id).Billing_Contact__c && acc.Billing_Contact__c != null ){
                        acc.BillingStreet = contactMap.get(acc.billing_contact__c).MailingStreet;
                        acc.BillingState = contactMap.get(acc.billing_contact__c).MailingState;
                        acc.Billingpostalcode = contactMap.get(acc.billing_contact__c).Mailingpostalcode;
                        acc.BillingCity = contactMap.get(acc.billing_contact__c).Mailingcity;
                        acc.BillingCountry = contactMap.get(acc.billing_contact__c).mailingcountry;
                        acc.Billing_Contact_Email__c = contactMap.get(acc.Billing_Contact__c).Email;
                        acc.Billing_Contact_Name__c = contactMap.get(acc.Billing_Contact__c).Full_Name__c;
                        acc.Billing_Contact_Phone__c = contactMap.get(acc.Billing_Contact__c).Phone;
                        acc.NSID_Billingaddress__c = contactMap.get(acc.Billing_Contact__c).NSID_Billingaddress__c;
                    } 
                    //if shipping contact is updated and not same as billing contact
                    else if(acc.billing_contact__c != acc.shipping_contact__c && acc.shipping_contact__c != trigger.oldmap.get(acc.Id).shipping_contact__c && acc.shipping_contact__c != null){
                        acc.ShippingStreet = contactMap.get(acc.shipping_contact__c).MailingStreet;
                        acc.ShippingState = contactMap.get(acc.shipping_contact__c).MailingState;
                        acc.Shippingpostalcode = contactMap.get(acc.shipping_contact__c).Mailingpostalcode;
                        acc.ShippingCity = contactMap.get(acc.shipping_contact__c).Mailingcity;
                        acc.ShippingCountry = contactMap.get(acc.shipping_contact__c).mailingcountry;
                        acc.Shipping_Contact_Name__c=contactMap.get(acc.shipping_contact__c).Full_Name__c;
                        acc.Shipping_Contact_Phone__c=contactMap.get(acc.shipping_contact__c).Phone;
                        acc.NSID_Shippingaddress__c=contactMap.get(acc.shipping_contact__c).NSID_Shippingaddress__c;
                    }
                    //if billing address is changed
                    else if(acc.BillingStreet != trigger.oldmap.get(acc.Id).BillingStreet
                            || acc.BillingStatecode != trigger.oldmap.get(acc.Id).BillingStatecode || acc.Billingpostalcode != trigger.oldmap.get(acc.Id).Billingpostalcode
                            || acc.BillingCity != trigger.oldmap.get(acc.Id).BillingCity || acc.BillingCountrycode != trigger.oldmap.get(acc.Id).BillingCountrycode){
                                if(acc.billing_contact__c == acc.shipping_contact__c && acc.billing_contact__c != null){
                                    acc.ShippingStreet = acc.BillingStreet;
                                    //acc.ShippingState = acc.BillingState;
                                    acc.ShippingStatecode = acc.BillingStatecode;
                                    acc.Shippingpostalcode = acc.Billingpostalcode;
                                    acc.ShippingCity = acc.BillingCity;
                                    //acc.ShippingCountry = acc.BillingCountry;
                                    acc.ShippingCountrycode = acc.BillingCountrycode;
                                }
                                
                            }
                    //if shipping address is changed
                    else if(acc.ShippingStreet != trigger.oldmap.get(acc.Id).ShippingStreet || acc.ShippingStatecode != trigger.oldmap.get(acc.Id).ShippingStatecode 
                            || acc.Shippingpostalcode != trigger.oldmap.get(acc.Id).Shippingpostalcode || acc.ShippingCity != trigger.oldmap.get(acc.Id).ShippingCity 
                            || acc.ShippingCountrycode != trigger.oldmap.get(acc.Id).ShippingCountrycode){
                                if(acc.billing_contact__c == acc.shipping_contact__c && acc.shipping_contact__c != null){
                                    acc.BillingStreet = acc.ShippingStreet;
                                    //acc.BillingState = acc.ShippingState;
                                    acc.BillingStatecode = acc.ShippingStatecode;
                                    acc.Billingpostalcode = acc.Shippingpostalcode;
                                    acc.BillingCity = acc.ShippingCity;
                                    //acc.BillingCountry = acc.ShippingCountry;
                                    acc.BillingCountrycode = acc.ShippingCountrycode;
                                }
                            }
                }
            }
        }
        
        
        else {
            if(!Trigger.isDelete){
                if(ContactTriggerHelper.contactaddressboolean== false)
                    AccountTriggerHandler.updateAddress(trigger.new,trigger.oldmap,trigger.isinsert);
            }
            if(Trigger.isUpdate){
                if(!Trigger.isDelete){
                    if(TriggerSwitchUtility.isTriggerActivated('AccountAddress')){
                        AccountTriggerHandler.updateOpenQuotes(trigger.new,trigger.oldmap); 
                    }
                    if(!AccountTriggerHandler.updatequotes && TriggerSwitchUtility.isTriggerActivated('BillParent')){
                        AccountTriggerHandler.updateQuoteAddress(trigger.new,trigger.oldmap);    
                        
                    }
                }
                if(!AccountTriggerHandler.updateChilds){
                    AccountTriggerHandler.updateChildAccounts(trigger.new);    
                }
                
                
                
                /*Set<Id> accIds = new Set<Id>();
List<Account> updatedAccounts = new List<Account>();
for(Account acc : Trigger.new){
Account oldAcc = Trigger.oldMap.get(acc.id);
if(acc.Active_ECI_ERP_Copy_Text__c!=oldAcc.Active_ECI_ERP_Copy_Text__c){
accIds.add(acc.Id);
updatedAccounts.add(acc);
}
}
Set<Id> accIds2 = accIds;
List<Account> childAccounts = [SELECT ID,Active_ECI_ERP_Copy_Text__c,Active_ECI_ERP_Parent__c,
ParentId,Parent.Active_ECI_ERP_Copy_Text__c, BillingCountry 
FROM Account 
WHERE ParentId IN :accIds];
for(Account acc : childAccounts){
accIds2.add(acc.Id);
updatedAccounts.add(acc);
}
List<User> cUsers = [SELECT ID,AccountId FROM User WHERE AccountId IN :accIds2 and IsActive=true];
if(cUsers.size()>0){
UserUtils.communityusers(updatedAccounts, cUsers);
}*/
            }
        }
    }
    if(Trigger.isAfter && Trigger.isUpdate){
        
        system.debug('division update from after update');
        Set<Id> accIds = New Set<Id>();
        for(Account a : trigger.new){
            if(a.NPS_Survey_Product__c != trigger.oldmap.get(a.id).NPS_Survey_Product__c && a.NPS_Survey_Product__c != Null){
                system.debug('from for loop if');
                accIds.add(a.Id);
            }
        }
        system.debug('size of accids:::   '+accIds.size());
        system.debug('accids:::   '+accIds);
        if(accIds.size() > 0){
            //AccountTriggerHandler.updateDivisionOnSurveyRes(accIds);
        }
        //updateVerticalAndPermissionSetAssignment
        set<Id> accIds1 = new Set<Id>();
        Map<Id,String> accProdListMap = new Map<Id,String>();
        Map<Id,String> accPriorProdListMap = new Map<Id,String>();
        
        for(Account acc : trigger.new){
            system.debug('Account ECI ERP Old, New :: '+trigger.oldMap.get(acc.Id).ECI_ERP__c+' --- '+acc.ECI_ERP__c);
            if(acc.ECI_ERP__c != trigger.oldMap.get(acc.Id).ECI_ERP__c){
                system.debug('Account ECI ERP change check');
                accIds1.add(acc.Id);
                accProdListMap.put(acc.Id, acc.ECI_ERP__c);
                accPriorProdListMap.put(acc.Id, trigger.oldMap.get(acc.Id).ECI_ERP__c);
            }
        }
        if(accIds1 != null && !accIds1.isEmpty() && System.IsBatch() == false && System.IsFuture() == false){
            system.debug('Account ECI ERP change; assignVertical call accIds1 : '+accIds1);
            AssignVerticalandPermissionsetHandler.updateVerticalAndPermissionSetAssignment(accIds1, accProdListMap, accPriorProdListMap);
            //AssignVerticalandPermissionsetHandler.updateVerticalAndPermissionSetAssignment2(accIds1, accProdListMap, accPriorProdListMap);
        }
    }
    if(Trigger.isAfter && (Trigger.isInsert || Trigger.isUpdate)){
        AccountTriggerHandler.createAccountCustomerNumberForQualifyingAccounts(Trigger.new, Trigger.oldMap, Trigger.isInsert);
        BankAliasSyncService.syncFromAccounts(Trigger.new, Trigger.oldMap, Trigger.isInsert);
        Set<Id> accIds = new Set<Id>();
        Set<Id> subsidiaryChangedAccounts = new Set<Id>();
        
        if (Trigger.isInsert) {
            AccountDefaultBillingAccountService.createDefaultBillingAccounts(Trigger.new);
            for (Account acc : Trigger.new) {
                accIds.add(acc.Id);
            }
        }
        
        if (Trigger.isUpdate) {
            
            for (Account acc : Trigger.new) {
                
                Account oldAcc = Trigger.oldMap.get(acc.Id);
                
                // 🔹 Only when support view changes (recommended)
                if (acc.Parent_Support_View__c != oldAcc.Parent_Support_View__c) {
                    accIds.add(acc.Id);
                }
            }
            for(Account acc : Trigger.new){
                Account oldAcc = Trigger.oldMap.get(acc.Id);
                
                if(acc.Subsidiary__c != oldAcc.Subsidiary__c){
                    subsidiaryChangedAccounts.add(acc.Id);
                }
            }
            
            if(!subsidiaryChangedAccounts.isEmpty()){
                ContactPermissionSetHandler.assignPermissionSetByAccount(
                    subsidiaryChangedAccounts
                );
            }
            
        }
        
        // 🔹 CALL QUEUEABLE
        if (!accIds.isEmpty()) {
            
            System.debug('🚀 Enqueue Queueable for Accounts: ' + accIds);
            
            System.enqueueJob(new AccountSharingQueueable(accIds));
        }
    }
    if(trigger.isBefore && trigger.isDelete){
        Set<Id> acIds = New Set<Id>();
        Set<Id> conIds = New Set<Id>();
        for(Account acc : trigger.old){
            acIds.add(acc.Id);
        }
        for(Contact c : [select Id, Name, AccountId from Contact where AccountId IN : acIds]){
            conIds.add(c.Id);
        }
        system.debug('AccountTrigger beforeDel cons:: '+conIds);
        AccountTriggerHandler.updateMergedAccContacts(conIds);
    }
    if(Trigger.isBefore && Trigger.isUpdate){
        AccountTriggerHandler.validateAccountType(Trigger.new,Trigger.oldmap); 
    }
}