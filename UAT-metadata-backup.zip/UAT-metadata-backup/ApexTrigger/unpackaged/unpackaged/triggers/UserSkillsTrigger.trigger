/*
 * SFDEV - 162 
 */
trigger UserSkillsTrigger on User_Skills__c (After delete) 
{
    if(Trigger.IsAfter && Trigger.IsDelete)
    {        
        UserSkillsTriggerHandler.afterDelete(Trigger.Old);     
    }

}