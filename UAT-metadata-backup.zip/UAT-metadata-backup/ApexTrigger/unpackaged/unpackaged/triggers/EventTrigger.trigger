trigger EventTrigger on Event (after insert,after update) {

    if(trigger.isAfter){
        EventTriggerHandler.accountUpdate(trigger.new,trigger.oldmap);
    }
}