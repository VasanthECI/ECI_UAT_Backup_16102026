trigger JiraAttachmentTrigger on peeklogic_jc__Jira_Attachment__c (after insert) {
    
    public static  peeklogic_jc__Jira_Admin_Settings__c settings { 
        get {
            if ( settings == null ){
                settings=peeklogic_jc__Jira_Admin_Settings__c.getOrgDefaults(); 
            } 
            return settings;
        } private set; }
    if(!settings.Disable_Jira_Issue_Trigger__c ){
        fflib_SObjectDomain.triggerHandler(JiraAttachmentTriggerHandler.class);
    }
    
}