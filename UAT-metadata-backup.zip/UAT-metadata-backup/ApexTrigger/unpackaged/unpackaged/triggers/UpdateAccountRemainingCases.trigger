trigger UpdateAccountRemainingCases on Entitlement (after insert, after update) {
//Sam Clyde - 7/2015 This trigger will sum all entitlements linked to an account 
//and update a custom field on the Account object. This field is used in Desk.com.
    List<Account> accList = new List<Account>();
    for (Entitlement e: Trigger.new) {
        Account acc = new Account(
            Id = e.AccountId,
            Desk_Cases_Remaining__c=[Select sum(RemainingCases) from Entitlement 
                                     where AccountId=:e.AccountId and EndDate >= Today And StartDate <= Today].Id
        );
        accList.add(acc);
        update accList;
    }
}