/**
 * Trigger Name: AiAutoResponsePositiveFeedback
 * Description: Platform event trigger that listens for positive customer feedback events
 *              (Ai_Auto_Response_Positive_Feedback__e) and delegates processing to
 *              AiAutoResponsePositiveFeedbackHandler. Enables asynchronous handling of
 *              AI case resolution, Einstein API integration, and automated case closure.
 * 
 * Author: Aruljothi
 * Date Created:
 * Last Modified: 2026-02-05
 */
trigger AiAutoResponsePositiveFeedback on Ai_Auto_Response_Positive_Feedback__e (after insert) {

    for (Ai_Auto_Response_Positive_Feedback__e evt : Trigger.new) {
        if (evt.Case_Id__c != null) {
            AiAutoResponsePositiveFeedbackHandler.executePositiveFeedback(evt.Case_Id__c);
system.debug('apex called');
        }
    }
}