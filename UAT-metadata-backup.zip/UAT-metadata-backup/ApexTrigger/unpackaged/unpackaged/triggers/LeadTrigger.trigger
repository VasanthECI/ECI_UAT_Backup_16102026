trigger LeadTrigger on Lead (before insert,before update,after insert,after update) {
    if(!TriggerSwitchUtility.isTriggerActivated('Lead')){
        System.debug('Lead Trigger disabled');
        return;    
    }
    system.debug('executing Lead trigger');
	LeadTriggerHelper leadhelper=new LeadTriggerHelper();
     if(trigger.isBefore){
        if(trigger.isInsert){
           leadhelper.onBeforeInsert(trigger.new);
        }
         if(trigger.isUpdate){
            leadhelper.onBeforeUpdate(Trigger.new,trigger.oldMap);
        }
     }
    if(trigger.isAfter){
        if(trigger.isUpdate && !LeadTriggerHelper.leadtrigger){
            leadhelper.onAfterUpdate(trigger.new,trigger.oldMap);
            LeadTriggerHelper.leadtrigger = true;
        }
        if(trigger.isInsert){
            leadhelper.updateLeadOwner(trigger.newMap);
        }
         if(trigger.isUpdate){
             leadhelper.updateLeadOwner(trigger.newMap);
         }
    }
}