/**
 * @description Trigger on `Order` that delegates billing-defaults processing to
 *              `OrderTriggerHandler`. Per the project standard, triggers contain
 *              no business logic; they only route trigger context to a handler.
 *
 *              Replaces the `OrderBeforeCreate` record-triggered flow. Fires:
 *              - `before insert`: resolves `BillToContactId` (alternate/parent
 *                billing model), snapshots the alternate billing fields, sets
 *                `LegalEntityId` from the Account Subsidiary, copies the bill-to
 *                Contact's address onto the Order, and flags `Billing_Error__c`.
 *
 *              The flow's `before update` path is intentionally not ported.
 *
 * @author Michael Morrell
 * @version 1.0
 * @since 2026-05-31
 */
trigger OrderTrigger on Order (before insert) {
    OrderTriggerHandler.beforeInsert(Trigger.new);
}