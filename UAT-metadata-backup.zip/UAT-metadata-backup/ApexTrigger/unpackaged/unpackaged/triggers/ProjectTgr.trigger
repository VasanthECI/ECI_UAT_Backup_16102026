/**
* Class Name: ProjectTgr
* Description: Single trigger on pse__Proj__c. Pure dispatcher — all logic lives in
*              ProjectTgrHandler (Case-Project sync, division stamping, PM reassignment).
*
* Author:
* Date Created:
* Last Modified:
*
* Version History
* Version : 1.5
* Author  : Consolidation
* Changes : Trigger reduced to single handler dispatch (no inline logic / no PMD
*           suppressions). Handler renamed to ProjectTgrHandler.
* Date    : 09/Jul/2026
*
* Version : 1.4
* Author  : Consolidation
* Changes : Merged ProjectTrigger PM-to-Case Owner reassignment into handler;
*           removed inline debug; one-trigger-per-object for pse__Proj__c
* Date    : 09/Jul/2026
*
* Version : 1.3
* Author  : Madhumitha
* Changes : SFDEV-1327 Handle Project becoming inactive - remove banners only (fields unchanged)
* Date    : 17/Dec/2025
*
* Version : 1.2
* Author  : Vidhya
* Changes : SFDEV-1192 New Fields needed (to be ran in a System Context)
*           Case-Project synchronization for project fields to case fields and vice versa if 1:1 realtionship exists
* Date    : 17/Sep/2025
*/
trigger ProjectTgr on pse__Proj__c (after Insert, after update, before insert, before update) {
    ProjectTgrHandler.handle();
}