trigger UpdateOppCampaign on Opportunity (after delete, after insert, after undelete, after update, before delete, before insert, before update) {
    if(trigger.isBefore){
        if(trigger.isInsert){
   
           /////////// non bulk trigger
           if(trigger.new.size() > 1){
            return;
           }
           /////////// non bulk trigger
         
           Opportunity o = trigger.new[0];
           System.debug('Akash --> o:' + o);
            System.debug('Akash --> 1:' + o.ECi_Product__c);
           
         
           if((o.Type_of_Sale__c == 'New System' || o.Type_of_Sale__c == 'Aftermarket')){
                
               list<Contact> lstContact = [Select Id From Contact Where AccountId = :o.AccountId ];
               list<Lead> lstLead = [Select Id From Lead Where Id  =: o.Leadid__c ];
               String soql = ' Select Id,CampaignId,Campaign.Type,Response_Tracking_Date__c,HasResponded__c,HasResponded, Campaign.Type_of_sale__c ';//Community comment
               soql += ' From CampaignMember ';
               soql += ' Where Campaign.ECi_Product__c = \'' + o.ECi_Product__c + '\' and Campaign.Type_of_sale__c = \''+ o.Type_of_Sale__c+'\'';
               
               System.debug('Akash --> lstContact:' +lstContact);
               System.debug('anuj--> LstLead:' +lstLead);
               /*    
               if(o.Type_of_Sale__c == 'Aftermarket'){
                soql += ' And Campaign.ECi_Aftermarket__c = \'' + o.ECi_Aftermarket__c + '\'';
               }
                */
               soql += ' And HasResponded__c = \'True\'';
               soql += ' And Response_Tracking_Date__c != null';
               soql += ' And ( ContactId In :lstContact OR LeadId In :lstLead )';
               soql += ' Order By Response_Tracking_Date__c Desc';
                
               System.debug('Akash --> soql:' + soql);
               List<CampaignMember> cmList = new List<CampaignMember>();
               cmList = Database.Query(soql);
               if(cmList.size() > 0){
                   for(CampaignMember cm: cmList){
                     
                       System.debug('Akash --> cm:' + cm);
                       System.debug('Akash --> cm.Campaign.Type:' + cm.Campaign.Type);
                         
                       Campaign_Type_Time_Mapping__c cttm = Campaign_Type_Time_Mapping__c.getall().get(cm.Campaign.Type); 
                    
                      
                         
                       if(cttm != null && cttm.Value__c != null){
                         
                           DateTime startDT = DateTime.now(); 
                           DateTime EndDT = DateTime.now();
                             
                           
                             
                           if(cttm.Type__c == 'Year'){
                                startDT = startDT.addYears(-1*Integer.valueOf(cttm.Value__c));
                           }else if(cttm.Type__c == 'Month'){
                                startDT = startDT.addMonths(-1*Integer.valueOf(cttm.Value__c));
                           }else if(cttm.Type__c == 'Day'){
                                startDT = startDT.addDays(-1*Integer.valueOf(cttm.Value__c));
                           }
                             
                           System.debug('Akash --> startDT:' + startDT);
                           System.debug('Akash --> EndDT:' + EndDT);
                            
                           if(cm.Response_Tracking_Date__c >= startDT && cm.Response_Tracking_Date__c <= EndDT){
                                
                               System.debug('Akash --> cm.Response_Tracking_Date__c:' + cm.Response_Tracking_Date__c);
                               System.debug('Akash --> startDT:' + startDT);
                               System.debug('Akash --> EndDT:' + EndDT);
                               if(cm.HasResponded)   //Community comment  
                                o.CampaignId = cm.CampaignId;
                               System.debug('Akash --> oppor \n' + o);
                               break;
                           }
                       }
                   }
               }else{
                    o.CampaignId = null;
               }    
           }
        }
    }
}