trigger RHX_License on License__c
    (after delete, after insert, after undelete, after update, before delete, before update) {
    if(UserInfo.getUserId() == label.ShoptechUserId){//'0053J000001MEj5QAG'
    return;
    }
     Type rollClass = System.Type.forName('rh2', 'ParentUtil');
     if(rollClass != null) {
        rh2.ParentUtil pu = (rh2.ParentUtil) rollClass.newInstance();
        if (trigger.isAfter) {
            pu.performTriggerRollups(trigger.oldMap, trigger.newMap, new String[]{'License__c'}, null);
        }
    }
       if(TriggerSwitchUtility.isTriggerActivated('License_Module__c')){
      if (Trigger.isBefore && Trigger.isUpdate) {
           system.debug(LicenseModuleManager.isAutomatedUpdate);
          if (System.isBatch()) {
        return;
          }
       
       if (!LicenseModuleManager.isAutomatedUpdate) {
        String skipValidation = System.Label.Skip_License_Validation;
           if(skipValidation != 'true'){
           
            for (License__c  newRecord : Trigger.new) {
                License__c  oldRecord = Trigger.oldMap.get(newRecord.Id);
                if (oldRecord.User_Counts__c != newRecord.User_Counts__c) {
                    newRecord.User_Counts__c.addError('User count cannot be changed directly. Please amend the contract for downsell or upsell so that user count will be calculated automatically.');
                }
            
            }
       
       }}

    }
       }
    
}