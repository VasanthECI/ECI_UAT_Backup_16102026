/* - - - - - - - - - - - - - - - - - - - - - -
 * CaseEmailTrigger
 * - - - - - - - - - - - - - - - - - - - - - - 
 * Original Author:
 * Unknown
 * - - - - - - - - - - - - - - - - - - - - - -
 * Purpose:
 * Process emails on Cases.
 * - - - - - - - - - - - - - - - - - - - - - -
 * Test Coverage:
 * CaseEmailTriggerTest
 * CaseEmailLegacyRefThreadingHandlerTest
 * - - - - - - - - - - - - - - - - - - - - - -
 * Revision History:
 * Date        Version   Author            Changes
 * 2019-Jan    2.0       redge-nehr        Removed old commented code. Cleaned up. Added before insert.
 * 2026-04-20  2.1       Michael Morrell   Wired CaseEmailLegacyRefThreadingHandler.rerouteByLegacyRef
 *                                          into before-insert so inbound emails carrying a legacy
 *                                          ref: token get re-parented to the original Case after the
 *                                          "Disable Ref ID" Release Update.
*/
trigger CaseEmailTrigger on EmailMessage 
(before insert, before update, before delete, after insert, after update, after delete) {
    
    if(Trigger.isBefore){
        
        if (Trigger.isDelete) {     
        }
        
        if(Trigger.isUpdate){      
        }
        
        //2019-01-17 - RelationEdge
        //it was requested to make all outbound
        //emails on cases Publicly Visible
        //so that they trigger closure of milestones
        if(Trigger.isInsert){
            // 2026-04-20 - Re-parent inbound emails carrying a legacy ref: token
            // to the original Case before the record is persisted.
            CaseEmailLegacyRefThreadingHandler.rerouteByLegacyRef(Trigger.new);

            for (EmailMessage c : Trigger.new) {							
                if(c.Incoming == false){													
                       c.IsExternallyVisible = true;
                   }
            }
        }
    }
    
    if(Trigger.isAfter){
        if(Trigger.isDelete){      
        }
        
        if(Trigger.isUpdate){     
        }
        
        if(Trigger.isInsert){

            // AptEdge: a customer reply on a Pending AptEdge Case reopens it (Status = Open),
            // clears AptEdge Case, and re-routes it via the assignment rules. Gated by the
            // "AptEdge" Trigger_Switch kill-switch inside the handler.
            AptEdgeInboundEmailHandler.handleIncoming(Trigger.new);

            // Make a set of Case IDs
            Set<ID> caseset = new Set<ID>();
            List<Case> caselist = new List<Case>();
            for (EmailMessage caseemail : Trigger.new)
            {
                if(caseemail.ParentID != null)
                {
                    id ParentID = caseemail.ParentID;
                    SObjectType objectType = ParentID.getSObjectType();
                    String objectName = objectType.getDescribe().getName(); 
                    if(objectName == System.Label.Case_Object_Name)
                        caseset.add(caseemail.ParentID);
                }
            }
            //System.debug('CaseEmailTrigger');
            if(caseset.size() > 0){
                CaseEmailTriggerHandler.createChildCase(Trigger.new, caseset); //Added as part of ticket 543 t create new case if parent case is closed
                caselist = [SELECT ID,To_Address__c from Case WHERE ID IN :caseset];
            
                // Loop through each case
                for (Case parentcase : caselist){
                    for(EmailMessage message : Trigger.new){
                        System.debug('Message date: '+message.MessageDate);
                        if(message.ParentID == parentcase.ID && message.incoming == true)
                        {
                            if(parentcase.To_Address__c == null){
                                parentcase.To_Address__c = message.ToAddress;
                            }
                        }
                    }                
                }
                
                try{
                    if(caselist.size() > 0)
                        UPDATE caselist;
                }
                catch(exception e)
                {
                    System.debug('***********'+e);
                }
            }
        }
    }
}