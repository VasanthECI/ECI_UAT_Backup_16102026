trigger CaseEntitlement on Case (before insert) {
/*for (Case c : Trigger.new) {
    if(c.Priority== NULL){
        try{c.Priority='P3';
           }catch(QueryException ex) {
           
            }
    }
    if(c.entitlementid== NULL){
        try{c.entitlementid='550C0000000Ywa7';
           }catch(QueryException ex) {
           
            }
    }
}*/
    
}