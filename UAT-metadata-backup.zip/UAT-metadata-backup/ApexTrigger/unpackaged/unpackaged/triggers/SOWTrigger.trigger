trigger SOWTrigger on SOW__c (After Update, After Insert, before insert, before Update) {
    SOWTriggerHandler sh = new SOWTriggerHandler();
    list<SOW__c> sows = new list<SOW__c>();
    map<id,id> sowmap = new map<id,id>();
    map<id,id> sowoldmap = new map<id,id>();
    Set<Id> oppIds = new Set<Id>();
    list<SOW__c> sows2 = new list<SOW__c>();
    Set<Id> sowIds = new Set<Id>();
    
    for (SOW__c s : trigger.new) oppIds.add(s.Opportunity__c);
    
    Map<id,opportunity> oppmap = new Map<id,opportunity>([Select id,SBQQ__PrimaryQuote__c from opportunity where id in:oppIds ]);
    
    list<SOW__c> existingSOW = new list<SOW__c>([select Id, Opportunity__c from SOW__c where Opportunity__c IN : oppIds and Status__c != 'Declined']);
    Set<Id> existingSowOppIds = new Set<Id>();
    for(SOW__c s : existingSOW) existingSowOppIds.add(s.Opportunity__c);
    
    for(SOW__c so : Trigger.new){
        system.debug('so.Status__c   """""   '+so.Status__c);
        if(oppmap.get(so.Opportunity__c).SBQQ__PrimaryQuote__c == null  && so.Status__c == 'Waiting Approval' && (Trigger.isupdate && so.Status__c != trigger.oldmap.get(so.id).Status__c)){
            so.addError(label.SOWApprovalPrimaryQuoteMandatory);
        }
        if((Trigger.isupdate && so.Status__c != trigger.oldmap.get(so.id).Status__c)){
            // so.ownerid = so.Opportunity_Owner__c;
        }
        if(so.Final_Review_Doc__c == null  && so.Status__c == 'Completed' && (Trigger.isupdate && so.Status__c != trigger.oldmap.get(so.id).Status__c || Trigger.isinsert)){
            so.addError(label.SOWFinalDocMandatory);
        }
        system.debug('so.Reject_Reason__c'+so.Reject_Reason__c);
        system.debug('so.Status__c'+so.Status__c);
        //system.debug('trigger.oldmap.getso.id.Status__c '+trigger.oldmap.get(so.id).Status__c );
        if(Trigger.isupdate && so.Status__c == 'Rejected' && so.Status__c != trigger.oldmap.get(so.id).Status__c &&
           trigger.oldmap.get(so.id).Status__c == 'Waiting Approval' && so.Reject_Reason__c == null){
               system.debug('so.Reject_Reason__cins'+so.Reject_Reason__c);
               so.addError(label.SOWRejectReasonMandatory);
           }
        if(Trigger.isAfter && Trigger.isupdate && so.Status__c == 'Rejected' && so.Status__c != trigger.oldmap.get(so.id).Status__c &&
           trigger.oldmap.get(so.id).Status__c == 'Waiting Approval' ){
               sowIds.add(so.Id);
               //  so.ownerid = '0053b00000BY2Bs'; /// need to assign to old owner
           }
        
        if((trigger.isAfter && Trigger.isinsert && so.ownerid != so.Opportunity_Owner__c)|| (Trigger.isUpdate && (so.Opportunity_Owner__c != trigger.oldmap.get(so.id).Opportunity_Owner__c || so.ownerid != trigger.oldmap.get(so.id).ownerid) && so.ownerid !=so.Opportunity_Owner__c)){
            sowmap.put(so.id,so.Opportunity_Owner__c);
            if(Trigger.isUpdate && so.Opportunity_Owner__c != trigger.oldmap.get(so.id).Opportunity_Owner__c){
                sowoldmap.put(so.id,trigger.oldmap.get(so.id).Opportunity_Owner__c);
            }
        }
        if(Trigger.isupdate && so.Status__c == 'Completed' && so.Status__c != trigger.oldmap.get(so.id).Status__c){
            //(new DOCTOPDFConvertor()).convertDocxToPdf(so.Final_Review_Doc__c); 
        }
        if(Trigger.isBefore && Trigger.isupdate && so.Status__c == 'Waiting Approval' && so.Status__c != trigger.oldmap.get(so.id).Status__c && so.OwnerId != so.Opportunity_Owner__c){
            sows2.add(so);
        }
        if(trigger.isBefore && trigger.isInsert && existingSowOppIds.contains(so.Opportunity__c)){
            so.addError(label.OneSOWPerOpportunity);
        }
    }
    if(!sows2.isEmpty()){
        SOWTriggerHandler.updateOwner(sows2);
    }
    if(!sowIds.isEmpty()){
        SOWTriggerHandler.updateOwnerifStatusReopened(sowIds);
    }
    if(sowmap.keySet().size()>0){
        sh.insertSOWShareRecord(sowmap); 
    }
    
    //sh.insertShareRecords(trigger.new);
    
}