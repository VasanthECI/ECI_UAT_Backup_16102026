trigger UpdateCaseFromCreationLog on V1CreationLog__c (after insert) {
    List<Case> caseList = new List<Case>();
    List<FeedItem> feedItemList = new List<FeedItem>();
    
    for (V1CreationLog__c v1cl : trigger.new) {
        List<Case> mycases = [SELECT Id FROM Case WHERE Id = :v1cl.Origin_Case__c];
        for (Case mycase : mycases) {
            mycase.V1_Target_Asset_OID__c = v1cl.V1_Target_Asset_OID__c;
            mycase.V1_Expression_Root__c = v1cl.V1_Root_Expression_OID__c;
            mycase.Request_No__c = v1cl.V1_Request_Number__c;
            
            FeedItem fi = new FeedItem(
                ParentId = mycase.Id,
                createdById = V1API.SF_DESKAPI_USER_ID,
                Body = 'Case has been linked to ' + v1cl.V1_Request_Number__c + ' on VersionOne.',
                isRichText = true
            );
            
            caseList.addAll(mycases);
            feedItemList.add(fi);
        }
    }
    
    update caseList;
    insert feedItemList;
}