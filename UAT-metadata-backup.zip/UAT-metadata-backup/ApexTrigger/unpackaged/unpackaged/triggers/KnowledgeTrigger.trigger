trigger KnowledgeTrigger on Knowledge__kav (after insert) {
	
    Set<id> knowledgeids = new set<id>();
    map<id,id> childParentmap = new map<id,id>();
    for(Knowledge__kav k : trigger.new){
         system.debug('%%%1'+k.MasterVersionId);
        if(k.MasterVersionId != k.id && k.MasterVersionId != null){
            system.debug('%%%2'+k.MasterVersion.Product__c);
			knowledgeids.add(k.id);
            childParentmap.put(k.id,k.MasterVersionId);
        }  
    }
    if(knowledgeids.size()>0){
        KnowledgeTriggerhelper.knowledgearticles(knowledgeids,childParentmap);
    }
    

}