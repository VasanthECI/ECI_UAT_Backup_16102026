/**
* Apex Class : LicenseModuleTrigger
* Description  :This class will assign ShopPinCode and update Original_License_Module__c in LicenseModule before insert.
* 
* Author: Yugashift
* Date Created: 5-8-2025
* Last Modified: 
* 
* Version History:
* Version :  
* Author  :  
* Changes : Added updateOriginalLicenseModule functionality 
* Date    :  
*
* Version : 1.1
* Author  : Aruljothi
* Changes : Use TriggerSwitchCache.isTriggerActive for Trigger_Switch__mdt (one SOQL per transaction).
* Date    : 22/Apr/2026
*/
trigger LicenseModuleTrigger on License_Module__c (before insert, before update) {
    
    if(TriggerSwitchCache.isTriggerActive('License_Module__c')){
        System.debug('LicenseModule Trigger Activated');
        if (Trigger.isBefore && Trigger.isInsert) {
            LicenseModuleTriggerHandler.assignShopPinCodes(Trigger.new);
            LicenseModuleTriggerHandler.updateOriginalLicenseModule(Trigger.new);
        }
    
    
    if (Trigger.isBefore && Trigger.isUpdate) {
        // Check if this is a manual update or automated update
        if (!LicenseModuleManager.isAutomatedUpdate) {
            String skipValidation = System.Label.Skip_License_Validation;
           if(skipValidation != 'true'){
            for (License_Module__c newRecord : Trigger.new) {
                License_Module__c oldRecord = Trigger.oldMap.get(newRecord.Id);
                if (oldRecord.User_Count__c != newRecord.User_Count__c) {
                    newRecord.User_Count__c.addError('User count cannot be changed directly. Please amend the contract for downsell or upsell so that user count will be calculated automatically.');
                }
            }
        }
        
        }
    }
        
    }
}