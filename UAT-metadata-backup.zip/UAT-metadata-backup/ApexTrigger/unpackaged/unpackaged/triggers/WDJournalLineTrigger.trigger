/**
 * @description Guard trigger for WD_Journal_Line__c (see WDJournalGuardTriggerHandler).
 */
trigger WDJournalLineTrigger on WD_Journal_Line__c (before delete) {
    WDJournalGuardTriggerHandler.beforeDeleteLines(Trigger.old);
}