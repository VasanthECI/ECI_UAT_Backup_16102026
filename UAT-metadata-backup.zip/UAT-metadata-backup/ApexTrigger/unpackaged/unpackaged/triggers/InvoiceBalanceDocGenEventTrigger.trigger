/**
 * @description Platform Event trigger for silent Invoice PDF regeneration.
 *              Runs as Automated Process so DocumentGenerationProcess is created with
 *              template ContentVersion access without sharing templates to portal users.
 *
 * @author Jayanthi
 * @since 2026-07-29
 * @see InvoiceBalanceDocGenEventTriggerHandler
 */
trigger InvoiceBalanceDocGenEventTrigger on Invoice_Balance_Doc_Gen__e (after insert) {
    InvoiceBalanceDocGenEventTriggerHandler.process(Trigger.new);
}