/**
* Apex Class : UserTrigger
* Description  : User object trigger.
* 
* Author: 
* Date Created: 
* Last Modified: 2026/06/08
* 
* 
* Version History:
*
* Version : 1.3
* Author  : Portal Team
* Changes : On after insert, call ContactPermissionSetHandler.assignPermissionSet for active
*           portal users (IsActive, IsPortalEnabled, ContactId) to assign subsidiary permission sets.
* Date    : 2026/06/08
*
* Version : 1.2
* Author  : Naveen S
* Changes : Added logic to trigger UserTriggerHandler.handleAfterInsertFuture
*           for users with profiles 'ECI Customer Exp User' and 
*           'ECI Customer Exp User - Advanced' on after insert/update.
*           Includes profile-based filtering and bulk-safe handling.
* Date    : 04/30/2026
*
* Version History:
* Version :  1.1
* Author  :  Vasanth
* Changes :  (SFDEV-1238) Update the class for call the UserTriggerHandler method handleManagerChange().
* Date    :  Oct-8-2025
*/



trigger UserTrigger on User
(before insert, before update, before delete, after insert, after update, after delete) {
    if(Trigger.isBefore){
        
    } else {
        list<id> disConts = new list<id>();
        if(Trigger.isupdate){            
            List<id> ownerUsers = new List<id>();
            for(User u : Trigger.new){
                if(u.ContactId != null && trigger.oldmap.get(u.id).IsPortalEnabled && u.IsActive != trigger.oldmap.get(u.id).IsActive && u.IsActive == false){
                    disConts.add(u.ContactId);
                }
            }
        }
        list<id> conids = new list<id>();
        if(Trigger.isInsert){
            Set<Id> accIds = new Set<Id>();
            //Set<Id> uIds = new Set<Id>();
            
            Map<Id,List<Id>> accMap = new Map<Id,List<Id>>();
            //List<User> comUsers = new List<User>();
            
            for(User u : Trigger.new){
                if(u.UserType=='CustomerSuccess' || u.UserType=='CspLitePortal'){
                    accIds.add(u.AccountId);
                    if(accMap.containsKey(u.AccountId)){
                        accMap.get(u.AccountId).add(u.Id);
                    } else {
                        List<Id> tempList = new List<Id>();
                        tempList.add(u.Id);
                        accMap.put(u.AccountId,tempList);
                    }
                    //uIds.add(u.Id);
                    //comUsers.add(u);
                }
                if(u.isactive && u.Contactid != null && u.IsPortalEnabled){
                    conids.add(u.ContactId);
                }
            }
            
            //Map<Id,List<String>> accProdMap = new Map<Id,List<String>>();
            /*List<Account> accs = [SELECT ID,Active_ECI_ERP_Copy_Text__c,Active_ECI_ERP_Parent__c,
ParentId,Parent.Active_ECI_ERP_Copy_Text__c, BillingCountry
FROM Account 
WHERE ID IN :accIds];
if(accs.size()>0){
//UserUtils.communityusers(accs, comUsers);

}*/
            
            
        }
        system.debug('conids'+conids);
        system.debug('disConts'+disConts);
        
        list<contact> updatecontact = new list<contact>();
        /*if(conids.size()>0){
for(contact con : [Select id, Is_Community_Portal_User__c from contact where id In:conids ]){
contact c = new contact();
c.id = con.id;
c.Is_Community_Portal_User__c = true;
updatecontact.add(c);
}
}
if(disConts.size()>0){
for(contact con : [Select id, Is_Community_Portal_User__c from contact where id In:disConts ]){
contact c = new contact();
c.id = con.id; 
c.Is_Community_Portal_User__c = false;
updatecontact.add(c);
} 
}*/
        system.debug('updatecontact'+updatecontact);
        
        if(!system.isFuture() && !system.isBatch())
            UserUtils.updatecontacts(conids,disConts);
        
        
    }
    if (Trigger.isAfter && (Trigger.isInsert || Trigger.isUpdate)) {
        
        // Step 1: Get all ProfileIds from users
        Set<Id> profileIds = new Set<Id>();
        for (User u : Trigger.new) {
            profileIds.add(u.ProfileId);
        }
        
        // Step 2: Query profile names
        Map<Id, String> profileMap = new Map<Id, String>();
        for (Profile p : [
            SELECT Id, Name 
            FROM Profile 
            WHERE Id IN :profileIds
        ]) {
            profileMap.put(p.Id, p.Name);
        }
        
        List<Id> userIds = new List<Id>();
        Set<Id> conids = new Set<Id>();
        
        // INSERT
        if (Trigger.isInsert) {
            for (User u : Trigger.new) {
                String profileName = profileMap.get(u.ProfileId);
                
                if (profileName == 'ECI Customer Exp User' ||
                    profileName == 'ECI Customer Exp User - Advanced') {
                        
                        userIds.add(u.Id);
                    }
                if(u.IsActive && u.ContactId != null && u.IsPortalEnabled){
                    conids.add(u.ContactId);
                }
            }
            
        }
        
        // UPDATE
        if (Trigger.isUpdate) {
            for (User u : Trigger.new) {
                User oldUser = Trigger.oldMap.get(u.Id);
                
                String profileName = profileMap.get(u.ProfileId);
                
                if (u.ProfileId != oldUser.ProfileId &&
                    (profileName == 'ECI Customer Exp User' ||
                     profileName == 'ECI Customer Exp User - Advanced')) {
                         
                         userIds.add(u.Id);
                     }
            }
        }
        
        // Call once (bulk-safe)
        if (!userIds.isEmpty()) {
            UserTriggerHandler.handleAfterInsertFuture(userIds);
        }
        
        if (!conids.isEmpty()) {
            ContactPermissionSetHandler.assignPermissionSet(conids);
        }
    }
    
    if(Trigger.isAfter && Trigger.isUpdate ){
        
        UserTriggerHandler.handleManagerChange(Trigger.new, Trigger.oldMap);
        
    }
}