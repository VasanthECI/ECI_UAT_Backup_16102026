trigger UpdateChildAccount on Account (before update) {
    
    if(!TriggerSwitchUtility.isTriggerActivated('Account')){
        System.debug('UpdateChildAccount Trigger disabled');
        return;    
    }
    if(!AccountTriggerHandler.updateChilds){
        //AccountTriggerHandler.updateChildAccounts(trigger.new);   
    }
    
}