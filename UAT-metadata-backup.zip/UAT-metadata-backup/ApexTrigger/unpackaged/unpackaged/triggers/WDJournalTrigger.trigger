/**
 * @description Guard trigger for WD_Journal__c (see WDJournalGuardTriggerHandler).
 */
trigger WDJournalTrigger on WD_Journal__c (before update, before delete) {
    if (Trigger.isDelete) {
        WDJournalGuardTriggerHandler.beforeDeleteJournals(Trigger.old);
    } else if (Trigger.isUpdate) {
        WDJournalGuardTriggerHandler.beforeUpdateJournals(Trigger.oldMap, Trigger.new);
    }
}