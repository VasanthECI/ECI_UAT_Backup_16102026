/**
 * Trigger Name: CaseCommentTrigger
 * Description : Processes internal Case Comments posted by the AptEdge Integration User.
 *               When a comment contains the AptEdge "Post Type" template, delegates to
 *               AptEdgeCaseResolutionHandler which (for Resolution / Request for Information)
 *               emails the customer response, records it on the Case, stamps the Case fields,
 *               and sets the appropriate Status.
 *
 * Author      : Yugashift
 * Date Created: 12/10/2026
 */
trigger CaseCommentTrigger on CaseComment (after insert) {
    if (Trigger.isAfter && Trigger.isInsert) {
        AptEdgeCaseResolutionHandler.handleCaseComments(Trigger.new);
    }
}