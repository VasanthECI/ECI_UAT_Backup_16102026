/**
 * @description Routes staging after-insert events to the stage trigger handler.
 * @author Michael Morrell
 * @version 1.0
 * @since 2026-05-20
 */
trigger ECI_BillingHubStageTrigger on ECI_Billing_Hub_Stage__c (after insert) {
    ECI_BillingHubStage_TriggerHandler.run();
}