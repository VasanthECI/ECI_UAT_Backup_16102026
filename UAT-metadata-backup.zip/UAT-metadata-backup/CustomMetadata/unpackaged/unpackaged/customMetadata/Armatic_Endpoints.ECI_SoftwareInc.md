<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-SoftwareInc</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">lDa9vquT5N0MxhC-Of2WjIhYOXcr7UvOOk8-yZjaLplbuhT5dOaZelsSd2DvHHGAXgI9O6jVxn5c2fTMi9P3hSgJl7F0-N66KKo=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-SoftwareInc</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECI Software Solutions, Inc.</value>
    </values>
</CustomMetadata>
