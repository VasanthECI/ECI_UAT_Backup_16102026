<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-SoftwareBV</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">xsTBr4sWSkdiZ5oor3vvkyVw4c4eRe615zVAoM8wSoyseA4lfGTfC2yNOIE3RKR8J21JjiqD0bA5CgKJG5p5N7DOYaGO5XBxY3M=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-SoftwareBV</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECI Software Solutions B.V.</value>
    </values>
</CustomMetadata>
