<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>scheduleExpiredEntitlements</label>
    <protected>false</protected>
    <values>
        <field>Description__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Expected_runs_per_period__c</field>
        <value xsi:type="xsd:double">1.0</value>
    </values>
    <values>
        <field>Frequency_type__c</field>
        <value xsi:type="xsd:string">Daily</value>
    </values>
</CustomMetadata>
