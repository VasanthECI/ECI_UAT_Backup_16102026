<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>MoreInfoForAISummary NL</label>
    <protected>false</protected>
    <values>
        <field>Key__c</field>
        <value xsi:type="xsd:string">MoreInfoForAISummary</value>
    </values>
    <values>
        <field>LanguageCode__c</field>
        <value xsi:type="xsd:string">nl_NL</value>
    </values>
    <values>
        <field>Value__c</field>
        <value xsi:type="xsd:string">Voor meer informatie kunt u het meegeleverde artikel raadplegen.</value>
    </values>
    <values>
        <field>Values__c</field>
        <value xsi:type="xsd:string">Voor meer informatie kunt u het meegeleverde artikel raadplegen.</value>
    </values>
</CustomMetadata>
