<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-TopLevelPROD</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">nIQse9bYWpiudh1mmvD8ZpXbS69G183wBXgBf502tMT34Ref87V6TD25yNKz6A1dXN7sPdoqCloC9vIwqX7JJbb8gykn84vjUMg=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-TopLevelPROD</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECI Software Solutions Top Level PROD</value>
    </values>
</CustomMetadata>
