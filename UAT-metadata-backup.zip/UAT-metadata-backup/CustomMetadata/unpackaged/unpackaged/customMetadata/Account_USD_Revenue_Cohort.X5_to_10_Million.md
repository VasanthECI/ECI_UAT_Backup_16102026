<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>5 to 10 Million</label>
    <protected>false</protected>
    <values>
        <field>Cohort_Label__c</field>
        <value xsi:type="xsd:string">3) 5M-10M</value>
    </values>
    <values>
        <field>Max_Revenue__c</field>
        <value xsi:type="xsd:double">9999999.99</value>
    </values>
    <values>
        <field>Min_Revenue__c</field>
        <value xsi:type="xsd:double">5000000.0</value>
    </values>
</CustomMetadata>
