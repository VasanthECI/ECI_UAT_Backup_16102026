<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-Sweden</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">TqLlZIRH1jxxdgqIxBylYQbDQ4jvgnu7jbavBxeR4nmV3JMbmSaoKXBRsxINArzhEQGurYlEutkQgCVazQ0Ofo4eLStxrrPavuA=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-Sweden</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECI Software Solutions Sweden AB</value>
    </values>
</CustomMetadata>
