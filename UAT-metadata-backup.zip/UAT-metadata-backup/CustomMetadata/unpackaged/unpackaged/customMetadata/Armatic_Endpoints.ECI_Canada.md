<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-Canada</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">qI9IT1d2BSPUNY7u9Mg_XxKkcgF8MV-0PwaawsOWOD0lEkK7YNDf4xJrs2ihM5h634AOF3yT72nv4TkbgF-VCudWgNqNMCyzxFM=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-Canada</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECi Software Solutions Canada Inc.</value>
    </values>
</CustomMetadata>
