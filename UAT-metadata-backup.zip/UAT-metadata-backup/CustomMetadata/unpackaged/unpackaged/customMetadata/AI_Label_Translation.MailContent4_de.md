<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>MailContent4 de</label>
    <protected>false</protected>
    <values>
        <field>Key__c</field>
        <value xsi:type="xsd:string">MailContent4</value>
    </values>
    <values>
        <field>LanguageCode__c</field>
        <value xsi:type="xsd:string">de</value>
    </values>
    <values>
        <field>Value__c</field>
        <value xsi:type="xsd:string">Wenn das oben Genannte Ihr Problem gelöst hat, klicken Sie bitte unten auf das Daumen-nach-oben-Symbol, um Ihren Fall automatisch zu schließen.</value>
    </values>
    <values>
        <field>Values__c</field>
        <value xsi:type="xsd:string">Wenn das oben Genannte Ihr Problem gelöst hat, klicken Sie bitte unten auf das Daumen-nach-oben-Symbol, um Ihren Fall automatisch zu schließen.</value>
    </values>
</CustomMetadata>
