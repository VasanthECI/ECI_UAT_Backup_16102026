<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-Belgium</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">g3YU_u5gYrWciOA2CyEfaONtJSJjR6qnHmONoWBck9lGhKpBmSL4qdTPTDoXa9jAf1lu1yWUVQxRm2bSpBcpJakT2KI_L-XuAq0=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-Belgium</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECI Software Solutions Belgium BV</value>
    </values>
</CustomMetadata>
