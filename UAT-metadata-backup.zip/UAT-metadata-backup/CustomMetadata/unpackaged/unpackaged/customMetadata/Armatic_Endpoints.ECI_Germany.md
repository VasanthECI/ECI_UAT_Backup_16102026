<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-Germany</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">sNJQT-0LJF9V4ltsV3JTVwYPZq9NBb-28954XkML2j4JcVzkjimNmNTCGdnpKSlsEkYAD7j2nnTiRPVPsBWxpHOXP9pNsmDd5K8=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-German</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECI Software Solutions Germany GmbH</value>
    </values>
</CustomMetadata>
