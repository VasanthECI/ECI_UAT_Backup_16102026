<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Abatement 2 Month - Quarterly</label>
    <protected>false</protected>
    <values>
        <field>Abatement_Term__c</field>
        <value xsi:type="xsd:string">2</value>
    </values>
    <values>
        <field>Billing_Frequency__c</field>
        <value xsi:type="xsd:string">Quarterly</value>
    </values>
    <values>
        <field>Billing_Treatment_Id__c</field>
        <value xsi:type="xsd:string">1BTVE0000002vDV4AY</value>
    </values>
    <values>
        <field>Invoice_Schedule__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Order_Split_Category__c</field>
        <value xsi:type="xsd:string">REC</value>
    </values>
</CustomMetadata>
