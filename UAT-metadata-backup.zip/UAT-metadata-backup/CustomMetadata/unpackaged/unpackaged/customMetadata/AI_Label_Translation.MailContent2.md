<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>MailContent2</label>
    <protected>false</protected>
    <values>
        <field>Key__c</field>
        <value xsi:type="xsd:string">MailContent2</value>
    </values>
    <values>
        <field>LanguageCode__c</field>
        <value xsi:type="xsd:string">en_US</value>
    </values>
    <values>
        <field>Value__c</field>
        <value xsi:type="xsd:string">A team member will be with you shortly. While you await a response, we’ve included a possible solution below:</value>
    </values>
    <values>
        <field>Values__c</field>
        <value xsi:type="xsd:string">A team member will be with you shortly. While you await a response, we’ve included a possible solution below:</value>
    </values>
</CustomMetadata>
