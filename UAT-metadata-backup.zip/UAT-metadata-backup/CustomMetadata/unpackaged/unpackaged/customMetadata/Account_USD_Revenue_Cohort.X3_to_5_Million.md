<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>3 to 5 Million</label>
    <protected>false</protected>
    <values>
        <field>Cohort_Label__c</field>
        <value xsi:type="xsd:string">2) 3M-5M</value>
    </values>
    <values>
        <field>Max_Revenue__c</field>
        <value xsi:type="xsd:double">4999999.99</value>
    </values>
    <values>
        <field>Min_Revenue__c</field>
        <value xsi:type="xsd:double">3000000.0</value>
    </values>
</CustomMetadata>
