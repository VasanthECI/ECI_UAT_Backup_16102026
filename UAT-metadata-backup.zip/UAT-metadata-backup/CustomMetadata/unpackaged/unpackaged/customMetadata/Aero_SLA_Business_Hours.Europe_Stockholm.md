<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Europe/Stockholm</label>
    <protected>false</protected>
    <values>
        <field>Business_Hours_Name__c</field>
        <value xsi:type="xsd:string">AeroRoute SLA - EU Central</value>
    </values>
    <values>
        <field>Time_Zone_SID__c</field>
        <value xsi:type="xsd:string">Europe/Stockholm</value>
    </values>
</CustomMetadata>
