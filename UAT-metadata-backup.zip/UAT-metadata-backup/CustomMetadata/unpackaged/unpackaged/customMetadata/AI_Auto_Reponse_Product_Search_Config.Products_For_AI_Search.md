<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Products For AI Search</label>
    <protected>false</protected>
    <values>
        <field>Blacklist_Products__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>IsActive__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>Test_Products__c</field>
        <value xsi:type="xsd:string">Lasso</value>
    </values>
    <values>
        <field>Whitelist_Products__c</field>
        <value xsi:nil="true"/>
    </values>
</CustomMetadata>
