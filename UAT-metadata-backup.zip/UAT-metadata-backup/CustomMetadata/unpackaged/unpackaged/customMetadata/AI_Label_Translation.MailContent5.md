<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>MailContent5</label>
    <protected>false</protected>
    <values>
        <field>Key__c</field>
        <value xsi:type="xsd:string">MailContent5</value>
    </values>
    <values>
        <field>LanguageCode__c</field>
        <value xsi:type="xsd:string">en_US</value>
    </values>
    <values>
        <field>Value__c</field>
        <value xsi:type="xsd:string">If you still need help, you can tap thumbs-down or take no action, and a member of our team will step in to help you directly.</value>
    </values>
    <values>
        <field>Values__c</field>
        <value xsi:type="xsd:string">If it did not solve your issue, no action is needed (or you can click the thumbs-down below). Your feedback is appreciated.</value>
    </values>
</CustomMetadata>
