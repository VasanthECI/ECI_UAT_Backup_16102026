<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Template1_billing_phone_1</label>
    <protected>false</protected>
    <values>
        <field>Box_External_ID__c</field>
        <value xsi:type="xsd:string">billing_phone_1</value>
    </values>
    <values>
        <field>Default_Value__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Mapping_Type__c</field>
        <value xsi:type="xsd:string">External ID</value>
    </values>
    <values>
        <field>Object_Name__c</field>
        <value xsi:type="xsd:string">Quote Document</value>
    </values>
    <values>
        <field>Salesforce_Field_API_Path__c</field>
        <value xsi:type="xsd:string">SBQQ__Quote__r.SBQQ__Account__r.Billing_Contact__r.Phone</value>
    </values>
    <values>
        <field>Signer_Email__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Signer_Name__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Signing_Order__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Template_Name__c</field>
        <value xsi:type="xsd:string">Template1</value>
    </values>
</CustomMetadata>
