<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-JobBOSS</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">JUxZ2HdIijIgZSlwQNGGldM_HceNsyjaTuDj8Bw4W3HWqXLbyCRQj0I53fENTB7Jt43nx0KZ5x6FCuV5j_hkqs6nWDXCzXq8qhs=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-JobBOSS</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECi JobBOSS, LLC</value>
    </values>
</CustomMetadata>
