<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-Solutions2</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">ykNwo-E6-JSVOdkcdLRuaYl6q4yJCMwT6ffE7qswd1xb3rH-BKd2y7hBixPJZ73vxa5j7kqLNCjm4hqZtPnVYqB26uyKDND3CRI=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-Solutions2</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECI Solutions</value>
    </values>
</CustomMetadata>
