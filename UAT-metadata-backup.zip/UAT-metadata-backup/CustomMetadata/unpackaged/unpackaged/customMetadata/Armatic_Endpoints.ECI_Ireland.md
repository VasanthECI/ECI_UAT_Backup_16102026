<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-Ireland</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">keVPzhWbodJuMuvC2dCpDet7oBOI0OWU1Zm2Am615JMcNLHyfHC7xJujUvyAABsxRZx2IISBjkb2EUCOodm1gK8rtSCHXiNv3iw=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-Ireland</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECI Software Solutions Ireland Limited</value>
    </values>
</CustomMetadata>
