<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>No Employees</label>
    <protected>false</protected>
    <values>
        <field>Cohort_Label__c</field>
        <value xsi:type="xsd:string">7) NULL</value>
    </values>
    <values>
        <field>Max_Employees__c</field>
        <value xsi:type="xsd:double">0.0</value>
    </values>
    <values>
        <field>Min_Employees__c</field>
        <value xsi:type="xsd:double">0.0</value>
    </values>
</CustomMetadata>
