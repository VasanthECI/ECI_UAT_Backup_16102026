<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>MailContent5 de</label>
    <protected>false</protected>
    <values>
        <field>Key__c</field>
        <value xsi:type="xsd:string">MailContent5</value>
    </values>
    <values>
        <field>LanguageCode__c</field>
        <value xsi:type="xsd:string">de</value>
    </values>
    <values>
        <field>Value__c</field>
        <value xsi:type="xsd:string">Falls dies Ihr Problem nicht gelöst hat, ist keine weitere Aktion erforderlich (oder Sie können unten auf das Daumen-nach-unten-Symbol klicken). Ihr Feedback wird geschätzt.</value>
    </values>
    <values>
        <field>Values__c</field>
        <value xsi:type="xsd:string">Falls dies Ihr Problem nicht gelöst hat, ist keine weitere Aktion erforderlich (oder Sie können unten auf das Daumen-nach-unten-Symbol klicken). Ihr Feedback wird geschätzt.</value>
    </values>
</CustomMetadata>
