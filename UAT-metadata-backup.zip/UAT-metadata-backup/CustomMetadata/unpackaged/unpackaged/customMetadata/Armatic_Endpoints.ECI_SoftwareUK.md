<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-SoftwareUK</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">QwSpE48z82WbQE7JkUe4yKuzQu3oO0Pm8jvns4-SpHf5ls-pvqkHmVaSZF4XdZEHqNj54UEnjVk0qZTMOeJ7fwQ19g9i1iruqM8=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-SoftwareUK</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECi Software Solutions Limited</value>
    </values>
</CustomMetadata>
