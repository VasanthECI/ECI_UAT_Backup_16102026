<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-Spruce</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">YW6N9_U6VR_hzH_Cqf9kTHd8wRHW37w5YIyOgSY2VsJw1_g1N762iJ9g26rvqrwUpPQ6mgF0f_0j4DPbXkulpcZ86w5Ut5wYYy8=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-Spruce</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECI Spruce</value>
    </values>
</CustomMetadata>
