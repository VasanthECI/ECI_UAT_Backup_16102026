<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Default</label>
    <protected>false</protected>
    <values>
        <field>Data_Table_Max_Chain_Depth__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Data_Table_Max_Rows__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Engine_Max_Nodes__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Inbound_Campaign_Type__c</field>
        <value xsi:type="xsd:string">Inbound Inquiry</value>
    </values>
    <values>
        <field>Inbound_LIM_Field__c</field>
        <value xsi:type="xsd:string">mkto_si__Last_Interesting_Moment_Desc__c</value>
    </values>
    <values>
        <field>Inbound_Notes_Field__c</field>
        <value xsi:type="xsd:string">Marketo_Notes__c</value>
    </values>
    <values>
        <field>Intake_Default_Source__c</field>
        <value xsi:type="xsd:string">Salesforce</value>
    </values>
    <values>
        <field>Lead_Account_Lookup_Field__c</field>
        <value xsi:type="xsd:string">LeanData__Reporting_Matched_Account__c</value>
    </values>
    <values>
        <field>Match_Max_Candidates_Fetch__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Match_Max_Tokens_Per_Key__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Notification_Max_Recipients__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>SLA_Business_Hours_Prefix__c</field>
        <value xsi:type="xsd:string">AeroRoute SLA</value>
    </values>
    <values>
        <field>Sla_Max_Drain_Iterations__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Sla_Scan_Batch_Limit__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Sla_Warning_Fraction__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Task_Not_Started_Status__c</field>
        <value xsi:type="xsd:string">Not Started</value>
    </values>
</CustomMetadata>
