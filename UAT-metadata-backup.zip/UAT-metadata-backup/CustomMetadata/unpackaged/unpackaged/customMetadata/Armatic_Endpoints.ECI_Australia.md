<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-Australia</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">JK1oC6B39PgsEJ6vgbsgGZdbcW4XkwBBJPbkwW8fDCpd9HL0xz5D3pO_lhJ3dP7KyqafBAcX_L-1bCZlBv5FUPsKIe4lqKsDkHw=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-Australia</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECi Solutions Pty. Ltd.</value>
    </values>
</CustomMetadata>
