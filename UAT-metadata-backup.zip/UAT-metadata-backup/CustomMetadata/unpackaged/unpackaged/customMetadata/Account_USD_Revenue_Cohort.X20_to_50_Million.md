<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>20 to 50 Million</label>
    <protected>false</protected>
    <values>
        <field>Cohort_Label__c</field>
        <value xsi:type="xsd:string">5) 20M-50M</value>
    </values>
    <values>
        <field>Max_Revenue__c</field>
        <value xsi:type="xsd:double">4.999999999E7</value>
    </values>
    <values>
        <field>Min_Revenue__c</field>
        <value xsi:type="xsd:double">2.0E7</value>
    </values>
</CustomMetadata>
