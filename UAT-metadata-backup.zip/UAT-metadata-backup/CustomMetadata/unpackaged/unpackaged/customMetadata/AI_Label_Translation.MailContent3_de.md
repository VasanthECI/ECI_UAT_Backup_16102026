<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>MailContent3 de</label>
    <protected>false</protected>
    <values>
        <field>Key__c</field>
        <value xsi:type="xsd:string">MailContent3</value>
    </values>
    <values>
        <field>LanguageCode__c</field>
        <value xsi:type="xsd:string">de</value>
    </values>
    <values>
        <field>Value__c</field>
        <value xsi:type="xsd:string">Diese Ressourcen könnten Ihnen ebenfalls hilfreich sein:</value>
    </values>
    <values>
        <field>Values__c</field>
        <value xsi:type="xsd:string">Diese Ressourcen könnten Ihnen ebenfalls hilfreich sein:</value>
    </values>
</CustomMetadata>
