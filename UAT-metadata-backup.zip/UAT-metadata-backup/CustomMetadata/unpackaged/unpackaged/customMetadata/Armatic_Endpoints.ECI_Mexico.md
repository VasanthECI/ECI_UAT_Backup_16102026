<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-Mexico</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">NEWDwu1JwYFen_zf5HWca9JtD8onuZ27Oj-LKqU_1EKDiqZGGAAbjFgukjgnco0er9wGVNCwvFGCWqnYqewi0txYxeAYqAqFHBI=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-Mexico</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECi Eclipse de Mexico, S.A. de C.V.</value>
    </values>
</CustomMetadata>
