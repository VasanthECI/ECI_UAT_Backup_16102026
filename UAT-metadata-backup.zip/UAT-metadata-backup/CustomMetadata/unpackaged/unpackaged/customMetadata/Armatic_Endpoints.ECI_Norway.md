<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-Norway</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">i-7M5RuJMkHyPS4sFPtdFSHFiSh11RbsbISF7BgSzRZH1T02bJo9PXeVojxu0VUIzWDsvy7gVY_gyCo61Ja7z-iSp_uxbP-3eR8=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-Norway</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECI Software Solutions Norway AS</value>
    </values>
</CustomMetadata>
