<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-MacolaMAX</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">MzJD2XGZjqvHToTRwm4LJ9Nf8wJWfDar5Jt5XsiC9wUGMYoBeCAbLJyIqAnSNi7LWjb8E1kODZpbZMxAmTIeN-PZ-ZHFsr33fc8=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-MacolaMAX</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECi Macola/MAX, LLC</value>
    </values>
</CustomMetadata>
