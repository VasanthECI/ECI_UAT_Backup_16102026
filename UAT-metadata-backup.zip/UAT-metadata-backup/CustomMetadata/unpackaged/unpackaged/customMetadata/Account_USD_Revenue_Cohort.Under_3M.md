<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Under 3M</label>
    <protected>false</protected>
    <values>
        <field>Cohort_Label__c</field>
        <value xsi:type="xsd:string">1) 0.1M-3M</value>
    </values>
    <values>
        <field>Max_Revenue__c</field>
        <value xsi:type="xsd:double">2999999.99</value>
    </values>
    <values>
        <field>Min_Revenue__c</field>
        <value xsi:type="xsd:double">1.0</value>
    </values>
</CustomMetadata>
