<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>ECI-Nederland</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">cFDnYMrDzVCsI-vzSDL3HyxK3IpdvX_637y1IYafI6Bowrr6INurR0KzOk5J-0ISIYjj0rDZIvJx2gZ_8pzp6fr1A9lrn0RETR4=</value>
    </values>
    <values>
        <field>Company_Code__c</field>
        <value xsi:type="xsd:string">ECI-Nederland</value>
    </values>
    <values>
        <field>Company_Name__c</field>
        <value xsi:type="xsd:string">ECi Software Solutions Nederland BV</value>
    </values>
</CustomMetadata>
